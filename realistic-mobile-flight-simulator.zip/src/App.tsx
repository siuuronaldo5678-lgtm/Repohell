import { useEffect, useState } from 'react';
import Menu from './components/Menu';
import GameScreen from './components/GameScreen';
import type { GameSettings } from './game/Game';

const isTouch = typeof window !== 'undefined' && ('ontouchstart' in window || navigator.maxTouchPoints > 0);

const DEFAULTS: GameSettings = {
  aircraft: 'skyhawk',
  time: 'day',
  invertY: false,
  assist: true,
  quality: isTouch ? 'low' : 'medium',
  startInAir: false,
  sound: true,
};

async function enterImmersive() {
  try {
    const el = document.documentElement;
    if (!document.fullscreenElement && el.requestFullscreen) await el.requestFullscreen();
  } catch {
    /* not allowed — ignore */
  }
  try {
    const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> };
    await o.lock?.('landscape');
  } catch {
    /* not supported — ignore */
  }
}

export default function App() {
  const [settings, setSettings] = useState<GameSettings>(() => {
    try {
      const saved = localStorage.getItem('skybound-settings');
      return saved ? { ...DEFAULTS, ...JSON.parse(saved) } : DEFAULTS;
    } catch {
      return DEFAULTS;
    }
  });
  const [playing, setPlaying] = useState(false);
  const [portrait, setPortrait] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem('skybound-settings', JSON.stringify(settings));
    } catch {
      /* ignore */
    }
  }, [settings]);

  useEffect(() => {
    const check = () => setPortrait(window.innerHeight > window.innerWidth && window.innerWidth < 700);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden bg-slate-900 font-sans">
      {playing ? (
        <GameScreen settings={settings} onExit={() => setPlaying(false)} />
      ) : (
        <Menu
          settings={settings}
          onChange={setSettings}
          onStart={() => {
            if (isTouch) void enterImmersive();
            setPlaying(true);
          }}
        />
      )}
      {portrait && (
        <div className="pointer-events-none absolute inset-x-0 top-0 z-50 flex justify-center p-2">
          <div className="rounded-full bg-amber-400/95 px-4 py-1.5 text-xs font-bold text-slate-900 shadow-lg">
            ⟳ Rotate your phone to landscape for the best view
          </div>
        </div>
      )}
    </div>
  );
}
