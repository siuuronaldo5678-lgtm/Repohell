import { useEffect, useRef, useState } from 'react';
import { Game, type GameSettings, type HudState } from '../game/Game';
import { controls } from '../game/input';
import Hud from './Hud';
import TouchControls from './TouchControls';

const EMPTY: HudState = {
  ready: false,
  loading: 0,
  speedKt: 0,
  altFt: 0,
  aglFt: 0,
  vsFpm: 0,
  heading: 0,
  pitch: 0,
  roll: 0,
  throttle: 0,
  gear: 1,
  gearDown: true,
  flaps: 0,
  brake: false,
  onGround: true,
  stall: false,
  pullUp: false,
  gearWarn: false,
  crashed: null,
  fps: 60,
  view: 0,
  g: 1,
  paused: false,
  nearest: null,
  map: [],
  stallKt: 50,
  vRotateKt: 55,
  aircraftName: '',
};

function Toggle({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      className="flex w-full items-center justify-between rounded-xl bg-white/10 px-4 py-2.5 text-left text-sm font-medium text-white active:bg-white/20"
      onClick={() => onChange(!on)}
    >
      <span>{label}</span>
      <span className={`relative h-6 w-11 rounded-full transition-colors ${on ? 'bg-emerald-500' : 'bg-white/25'}`}>
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${on ? 'left-[22px]' : 'left-0.5'}`}
        />
      </span>
    </button>
  );
}

export default function GameScreen({ settings, onExit }: { settings: GameSettings; onExit: () => void }) {
  const mount = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [hud, setHud] = useState<HudState>(EMPTY);
  const [local, setLocal] = useState(settings);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const el = mount.current;
    if (!el) return;
    let g: Game;
    try {
      controls.throttle = 0;
      g = new Game(el, settings, setHud);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'WebGL is not available on this device.');
      return;
    }
    gameRef.current = g;
    setGame(g);
    g.startAudio();
    return () => {
      g.dispose();
      gameRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const update = (patch: Partial<GameSettings>) => {
    setLocal((s) => ({ ...s, ...patch }));
    gameRef.current?.applySettings(patch);
  };

  const pause = (p: boolean) => {
    gameRef.current?.setPaused(p);
    gameRef.current?.startAudio();
  };

  if (error) {
    return (
      <div className="flex h-full items-center justify-center bg-slate-900 p-6 text-center text-white">
        <div>
          <p className="mb-4 text-lg font-semibold">Couldn't start 3D rendering</p>
          <p className="mb-6 text-sm text-white/70">{error}</p>
          <button className="rounded-xl bg-sky-500 px-6 py-3 font-bold" onClick={onExit}>
            Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative h-full w-full touch-none overflow-hidden bg-sky-900"
      onPointerDown={() => gameRef.current?.startAudio()}
    >
      <div ref={mount} className="absolute inset-0" />

      {hud.ready && !hud.crashed && !hud.paused && (
        <>
          <Hud hud={hud} onPause={() => pause(true)} />
          <TouchControls game={game} hud={hud} />
        </>
      )}

      {/* loading */}
      {!hud.ready && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-gradient-to-b from-sky-900 to-slate-900 text-white">
          <div className="mb-2 text-4xl">✈️</div>
          <div className="mb-3 text-lg font-semibold">Generating the world…</div>
          <div className="h-2 w-64 overflow-hidden rounded-full bg-white/15">
            <div
              className="h-full rounded-full bg-sky-400 transition-all duration-200"
              style={{ width: `${Math.max(6, hud.loading * 100)}%` }}
            />
          </div>
          <div className="mt-3 text-xs text-white/60">Terrain · Forests · Towns · Airports</div>
        </div>
      )}

      {/* crashed */}
      {hud.ready && hud.crashed && (
        <div className="absolute inset-0 flex items-center justify-center bg-red-950/60 p-4 backdrop-blur-[2px]">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900/95 p-5 text-center text-white shadow-2xl">
            <div className="text-3xl font-extrabold tracking-wide text-red-400">CRASHED</div>
            <p className="mt-1 mb-4 text-sm text-white/80">{hud.crashed}</p>
            <div className="flex flex-col gap-2">
              <button
                className="rounded-xl bg-sky-500 py-3 font-bold active:bg-sky-600"
                onClick={() => gameRef.current?.respawn(false)}
              >
                Restart at Home Airport
              </button>
              <button
                className="rounded-xl bg-white/15 py-3 font-semibold active:bg-white/25"
                onClick={() => gameRef.current?.respawn(true)}
              >
                Respawn at Nearest Runway
              </button>
              <button className="rounded-xl bg-white/10 py-2.5 text-sm active:bg-white/20" onClick={onExit}>
                Main Menu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* pause */}
      {hud.ready && hud.paused && !hud.crashed && (
        <div className="absolute inset-0 flex items-center justify-center overflow-y-auto bg-black/60 p-4 backdrop-blur-sm">
          <div className="my-auto w-full max-w-md rounded-2xl bg-slate-900/95 p-5 text-white shadow-2xl">
            <div className="mb-3 text-center text-xl font-bold">Paused</div>
            <div className="mb-3 grid grid-cols-2 gap-2">
              <button className="col-span-2 rounded-xl bg-sky-500 py-3 font-bold active:bg-sky-600" onClick={() => pause(false)}>
                ▶ Resume
              </button>
              <button
                className="rounded-xl bg-white/15 py-2.5 text-sm font-semibold active:bg-white/25"
                onClick={() => {
                  gameRef.current?.respawn(true);
                  pause(false);
                }}
              >
                Nearest runway
              </button>
              <button
                className="rounded-xl bg-white/15 py-2.5 text-sm font-semibold active:bg-white/25"
                onClick={() => {
                  gameRef.current?.respawn(false);
                  pause(false);
                }}
              >
                Home airport
              </button>
            </div>
            <div className="mb-3 flex flex-col gap-2">
              <Toggle label="Flight assist (auto-level & stall guard)" on={local.assist} onChange={(v) => update({ assist: v })} />
              <Toggle label="Invert pitch (drag up = nose up)" on={local.invertY} onChange={(v) => update({ invertY: v })} />
              <Toggle label="Sound" on={local.sound} onChange={(v) => update({ sound: v })} />
            </div>
            <button className="w-full rounded-xl bg-white/10 py-2.5 text-sm active:bg-white/20" onClick={onExit}>
              Exit to menu
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
