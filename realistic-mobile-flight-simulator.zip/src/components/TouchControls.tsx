import { useCallback, useRef, useState } from 'react';
import { controls } from '../game/input';
import type { Game, HudState } from '../game/Game';

const STICK_R = 62;

function stop(e: React.SyntheticEvent) {
  e.preventDefault();
  e.stopPropagation();
}

/** Floating virtual stick: touch anywhere in the left zone. */
function Stick() {
  const zone = useRef<HTMLDivElement>(null);
  const idRef = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });
  const [st, setSt] = useState({ active: false, ox: 0, oy: 0, kx: 0, ky: 0 });

  const down = (e: React.PointerEvent) => {
    if (idRef.current !== null) return;
    e.preventDefault();
    idRef.current = e.pointerId;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    const r = zone.current!.getBoundingClientRect();
    const ox = Math.min(Math.max(e.clientX - r.left, STICK_R), r.width - STICK_R);
    const oy = Math.min(Math.max(e.clientY - r.top, STICK_R), r.height - STICK_R);
    origin.current = { x: ox + r.left, y: oy + r.top };
    setSt({ active: true, ox, oy, kx: 0, ky: 0 });
  };
  const move = (e: React.PointerEvent) => {
    if (e.pointerId !== idRef.current) return;
    let dx = e.clientX - origin.current.x;
    let dy = e.clientY - origin.current.y;
    const d = Math.hypot(dx, dy);
    if (d > STICK_R) {
      dx = (dx / d) * STICK_R;
      dy = (dy / d) * STICK_R;
    }
    const nx = dx / STICK_R;
    const ny = -dy / STICK_R;
    const dead = 0.06;
    controls.stickX = Math.abs(nx) < dead ? 0 : nx;
    controls.stickY = Math.abs(ny) < dead ? 0 : ny;
    setSt((s) => ({ ...s, kx: dx, ky: dy }));
  };
  const up = (e: React.PointerEvent) => {
    if (e.pointerId !== idRef.current) return;
    idRef.current = null;
    controls.stickX = 0;
    controls.stickY = 0;
    setSt((s) => ({ ...s, active: false, kx: 0, ky: 0 }));
  };

  const idle = !st.active;
  return (
    <div
      ref={zone}
      className="pointer-events-auto absolute bottom-0 left-0 touch-none select-none"
      style={{ width: '46%', height: '62%' }}
      onPointerDown={down}
      onPointerMove={move}
      onPointerUp={up}
      onPointerCancel={up}
      onContextMenu={stop}
    >
      <div
        className="absolute rounded-full border-2 border-white/50 bg-white/10 backdrop-blur-[2px]"
        style={{
          width: STICK_R * 2,
          height: STICK_R * 2,
          left: idle ? 22 : st.ox - STICK_R,
          bottom: idle ? 22 : undefined,
          top: idle ? undefined : st.oy - STICK_R,
          opacity: idle ? 0.55 : 0.95,
        }}
      >
        <div className="absolute inset-0 flex items-center justify-center text-[10px] font-semibold text-white/60">
          {idle && (
            <>
              <span className="absolute top-1">▲</span>
              <span className="absolute bottom-1">▼</span>
              <span className="absolute left-2">◀</span>
              <span className="absolute right-2">▶</span>
            </>
          )}
        </div>
        <div
          className="absolute rounded-full border border-white/70 bg-sky-400/70 shadow-lg"
          style={{
            width: 54,
            height: 54,
            left: STICK_R - 27 + st.kx,
            top: STICK_R - 27 + st.ky,
          }}
        />
      </div>
    </div>
  );
}

function Throttle({ value }: { value: number }) {
  const track = useRef<HTMLDivElement>(null);
  const idRef = useRef<number | null>(null);
  const [local, setLocal] = useState<number | null>(null);

  const setFromEvent = (e: React.PointerEvent) => {
    const r = track.current!.getBoundingClientRect();
    const v = Math.min(1, Math.max(0, 1 - (e.clientY - r.top) / r.height));
    controls.throttle = v;
    setLocal(v);
  };
  const down = (e: React.PointerEvent) => {
    e.preventDefault();
    idRef.current = e.pointerId;
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    setFromEvent(e);
  };
  const move = (e: React.PointerEvent) => {
    if (e.pointerId === idRef.current) setFromEvent(e);
  };
  const up = (e: React.PointerEvent) => {
    if (e.pointerId !== idRef.current) return;
    idRef.current = null;
    setLocal(null);
  };
  const v = local ?? value;
  return (
    <div className="pointer-events-auto absolute right-3 bottom-4 flex flex-col items-center gap-1 select-none">
      <div className="text-[10px] font-bold tracking-wider text-white/80">THR</div>
      <div
        ref={track}
        className="relative w-14 touch-none rounded-2xl border-2 border-white/40 bg-black/35 backdrop-blur-sm"
        style={{ height: 'min(34vh, 190px)' }}
        onPointerDown={down}
        onPointerMove={move}
        onPointerUp={up}
        onPointerCancel={up}
        onContextMenu={stop}
      >
        <div
          className="absolute right-0 bottom-0 left-0 rounded-b-xl bg-gradient-to-t from-emerald-500/80 to-amber-400/80"
          style={{ height: `${v * 100}%` }}
        />
        <div
          className="absolute right-[-4px] left-[-4px] h-5 rounded-md border border-white bg-white/90 shadow-md"
          style={{ bottom: `calc(${v * 100}% - 10px)` }}
        />
      </div>
      <div className="text-xs font-bold text-white tabular-nums">{Math.round(v * 100)}%</div>
    </div>
  );
}

function HoldButton({
  label,
  onChange,
  className = '',
  children,
}: {
  label?: string;
  onChange: (down: boolean) => void;
  className?: string;
  children?: React.ReactNode;
}) {
  const [on, setOn] = useState(false);
  const idRef = useRef<number | null>(null);
  return (
    <button
      aria-label={label}
      className={`pointer-events-auto touch-none select-none rounded-2xl border-2 text-white backdrop-blur-sm transition-colors ${
        on ? 'border-sky-300 bg-sky-500/70' : 'border-white/40 bg-black/35'
      } ${className}`}
      onPointerDown={(e) => {
        e.preventDefault();
        idRef.current = e.pointerId;
        (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
        setOn(true);
        onChange(true);
      }}
      onPointerUp={(e) => {
        if (e.pointerId !== idRef.current) return;
        idRef.current = null;
        setOn(false);
        onChange(false);
      }}
      onPointerCancel={() => {
        idRef.current = null;
        setOn(false);
        onChange(false);
      }}
      onContextMenu={stop}
    >
      {children}
    </button>
  );
}

function TapButton({
  label,
  sub,
  active,
  onTap,
}: {
  label: string;
  sub?: string;
  active?: boolean;
  onTap: () => void;
}) {
  return (
    <button
      className={`pointer-events-auto flex h-11 min-w-[54px] touch-none flex-col items-center justify-center rounded-xl border-2 px-2 text-[11px] leading-tight font-bold tracking-wide text-white backdrop-blur-sm select-none active:scale-95 ${
        active ? 'border-emerald-300 bg-emerald-600/60' : 'border-white/40 bg-black/40'
      }`}
      onPointerDown={(e) => {
        e.preventDefault();
        onTap();
      }}
      onContextMenu={stop}
    >
      <span>{label}</span>
      {sub && <span className="text-[9px] font-semibold text-white/80">{sub}</span>}
    </button>
  );
}

export default function TouchControls({ game, hud }: { game: Game | null; hud: HudState }) {
  const rudder = useCallback((dir: number) => (d: boolean) => {
    controls.rudder = d ? dir : 0;
  }, []);
  const brake = useCallback((d: boolean) => {
    controls.brake = d;
  }, []);

  return (
    <div className="pointer-events-none absolute inset-0 touch-none select-none">
      <Stick />

      {/* top-right action buttons */}
      <div className="absolute top-2 right-3 flex gap-2">
        <TapButton label="GEAR" sub={hud.gear > 0.95 ? 'DOWN' : hud.gear < 0.05 ? 'UP' : '...'} active={hud.gearDown} onTap={() => game?.toggleGear()} />
        <TapButton label="FLAPS" sub={hud.flaps === 0 ? 'UP' : `${hud.flaps}/3`} active={hud.flaps > 0} onTap={() => game?.cycleFlaps()} />
        <TapButton label="VIEW" sub={['CHASE', 'COCKPIT', 'FAR'][hud.view]} onTap={() => game?.cycleView()} />
      </div>

      {/* rudder + brake */}
      <div className="absolute right-[88px] bottom-4 flex items-end gap-2">
        <HoldButton label="Brake" onChange={brake} className="h-14 w-16 text-xs font-bold">
          BRAKE
        </HoldButton>
        <HoldButton label="Rudder left" onChange={rudder(-1)} className="h-16 w-16 text-2xl">
          ⟲
        </HoldButton>
        <HoldButton label="Rudder right" onChange={rudder(1)} className="h-16 w-16 text-2xl">
          ⟳
        </HoldButton>
      </div>

      <Throttle value={hud.throttle} />
    </div>
  );
}
