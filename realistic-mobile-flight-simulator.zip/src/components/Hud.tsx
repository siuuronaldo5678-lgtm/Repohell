import { useEffect, useRef } from 'react';
import type { HudState } from '../game/Game';

const CARD = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
const cardinal = (h: number) => CARD[Math.round(h / 45) % 8];
const pad3 = (n: number) => String(Math.round(n) % 360).padStart(3, '0');

function MiniMap({ hud }: { hud: HudState }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const g = cv.getContext('2d')!;
    const S = cv.width;
    const c = S / 2;
    const range = 20000;
    const k = c / range;
    g.clearRect(0, 0, S, S);
    g.save();
    g.beginPath();
    g.arc(c, c, c - 1, 0, Math.PI * 2);
    g.clip();
    g.fillStyle = 'rgba(8,20,35,0.62)';
    g.fillRect(0, 0, S, S);
    // rotate heading-up
    g.translate(c, c);
    g.rotate((-hud.heading * Math.PI) / 180);
    g.strokeStyle = 'rgba(255,255,255,0.18)';
    g.lineWidth = 1;
    for (const r of [5000, 10000, 15000]) {
      g.beginPath();
      g.arc(0, 0, r * k, 0, Math.PI * 2);
      g.stroke();
    }
    // north marker
    g.fillStyle = '#ff6b6b';
    g.font = 'bold 11px sans-serif';
    g.textAlign = 'center';
    g.fillText('N', 0, -(c - 11));
    for (const p of hud.map) {
      const x = p.dx * k;
      const y = p.dz * k;
      g.fillStyle = '#4de1ff';
      g.fillRect(x - 3, y - 3, 6, 6);
    }
    g.restore();
    // aircraft
    g.fillStyle = '#ffffff';
    g.beginPath();
    g.moveTo(c, c - 7);
    g.lineTo(c + 5, c + 6);
    g.lineTo(c, c + 3);
    g.lineTo(c - 5, c + 6);
    g.closePath();
    g.fill();
    g.strokeStyle = 'rgba(255,255,255,0.5)';
    g.lineWidth = 2;
    g.beginPath();
    g.arc(c, c, c - 1, 0, Math.PI * 2);
    g.stroke();
  }, [hud.heading, hud.map]);
  return <canvas ref={ref} width={104} height={104} className="h-[88px] w-[88px] sm:h-[104px] sm:w-[104px]" />;
}

function Adi({ pitch, roll }: { pitch: number; roll: number }) {
  const size = 72;
  return (
    <div
      className="relative overflow-hidden rounded-full border-[3px] border-white/70 bg-black shadow-lg"
      style={{ width: size, height: size }}
    >
      <div
        className="absolute"
        style={{
          width: size * 3,
          height: size * 3,
          left: -size,
          top: -size,
          background: 'linear-gradient(to bottom, #3d8be0 0%, #8cc4f5 49.6%, #fff 49.6%, #fff 50.4%, #9a6a3a 50.4%, #5b3d22 100%)',
          transform: `rotate(${-roll}deg) translateY(${pitch * 1.3}px)`,
        }}
      >
        {[-20, -10, 10, 20].map((p) => (
          <div
            key={p}
            className="absolute left-1/2 h-[1.5px] -translate-x-1/2 bg-white/80"
            style={{ width: Math.abs(p) === 10 ? 26 : 40, top: `calc(50% - ${p * 1.3}px)` }}
          />
        ))}
      </div>
      {/* aircraft symbol */}
      <div className="absolute top-1/2 left-1/2 h-[3px] w-[44px] -translate-x-1/2 -translate-y-1/2 rounded bg-amber-400" />
      <div className="absolute top-1/2 left-1/2 h-2 w-2 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-amber-400 bg-black" />
      {/* bank pointer */}
      <div className="absolute top-0 left-1/2 h-0 w-0 -translate-x-1/2 border-x-[5px] border-t-[8px] border-x-transparent border-t-amber-400" />
    </div>
  );
}

function Readout({ label, value, unit, warn }: { label: string; value: string; unit: string; warn?: boolean }) {
  return (
    <div className="flex w-[64px] flex-col items-center rounded-lg bg-black/45 px-1.5 py-1 backdrop-blur-sm">
      <div className="text-[9px] font-bold tracking-widest text-white/60">{label}</div>
      <div className={`text-lg leading-none font-bold tabular-nums ${warn ? 'animate-pulse text-red-400' : 'text-white'}`}>
        {value}
      </div>
      <div className="text-[9px] text-white/60">{unit}</div>
    </div>
  );
}

export default function Hud({ hud, onPause }: { hud: HudState; onPause: () => void }) {
  const vsFmt = `${hud.vsFpm >= 0 ? '+' : ''}${Math.round(hud.vsFpm / 10) * 10}`;
  const cockpit = hud.view === 1;
  const showHint = hud.onGround && hud.speedKt < 4 && hud.throttle < 0.08 && !hud.crashed;
  const warnText = hud.stall ? 'STALL' : hud.pullUp ? 'TERRAIN — PULL UP' : hud.gearWarn ? 'GEAR!' : null;

  return (
    <div className="pointer-events-none absolute inset-0 select-none">
      {cockpit && (
        <div className="absolute inset-x-0 bottom-0 h-[20%] bg-gradient-to-t from-zinc-900 via-zinc-900/90 to-transparent" />
      )}
      {cockpit && <div className="absolute inset-x-0 top-0 h-[3%] bg-gradient-to-b from-zinc-900/80 to-transparent" />}

      {/* top-left: pause + minimap + nav */}
      <div className="absolute top-2 left-3 flex items-start gap-2">
        <button
          className="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-xl border-2 border-white/40 bg-black/40 text-lg text-white backdrop-blur-sm active:scale-95"
          onPointerDown={(e) => {
            e.preventDefault();
            onPause();
          }}
          aria-label="Pause"
        >
          ❚❚
        </button>
        <div className="flex flex-col items-start gap-1">
          <MiniMap hud={hud} />
          {hud.nearest && (
            <div className="rounded-md bg-black/50 px-2 py-0.5 text-[10px] leading-tight font-semibold text-cyan-200 backdrop-blur-sm">
              ✈ {hud.nearest.name}
              <br />
              {hud.nearest.km.toFixed(1)} km · BRG {pad3(hud.nearest.bearing)}°
            </div>
          )}
        </div>
      </div>

      {/* top center: heading */}
      <div className="absolute top-2 left-1/2 flex -translate-x-1/2 flex-col items-center gap-1">
        <div className="flex items-center gap-2 rounded-lg bg-black/45 px-3 py-1 backdrop-blur-sm">
          <span className="text-xl leading-none font-bold text-white tabular-nums">{pad3(hud.heading)}°</span>
          <span className="text-xs font-bold text-amber-300">{cardinal(hud.heading)}</span>
        </div>
        {warnText && (
          <div className="animate-pulse rounded-lg border border-red-300 bg-red-600/85 px-3 py-1 text-sm font-extrabold tracking-wider text-white shadow-lg">
            ⚠ {warnText}
          </div>
        )}
      </div>

      {/* bottom center instruments */}
      <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 items-end gap-1.5">
        <Readout label="SPEED" value={String(Math.round(hud.speedKt))} unit="KT" warn={hud.stall} />
        <div className="flex flex-col items-center gap-1">
          <Adi pitch={hud.pitch} roll={hud.roll} />
          <div className="rounded-md bg-black/45 px-2 py-0.5 text-[10px] font-semibold text-white/90 tabular-nums">
            {hud.g.toFixed(1)} G · {hud.fps} FPS
          </div>
        </div>
        <div className="flex flex-col items-center gap-1">
          <Readout label="ALT" value={String(Math.round(hud.altFt / 10) * 10)} unit="FT MSL" />
          <div className="flex gap-2 text-[10px] font-semibold text-white/90 tabular-nums">
            <span className="rounded bg-black/45 px-1.5 py-0.5">AGL {Math.round(hud.aglFt)}</span>
            <span className={`rounded bg-black/45 px-1.5 py-0.5 ${hud.vsFpm < -1500 ? 'text-red-300' : ''}`}>VS {vsFmt}</span>
          </div>
        </div>
      </div>

      {showHint && (
        <div className="absolute top-[30%] left-1/2 max-w-[78%] -translate-x-1/2 rounded-xl bg-black/55 px-4 py-2 text-center text-xs text-white backdrop-blur-sm sm:text-sm">
          <b>Ready for takeoff</b> — push the <b>THR</b> slider (right) to 100%, then pitch up (pull the
          stick back) at <b>{Math.round(hud.vRotateKt)} kt</b>.
        </div>
      )}
    </div>
  );
}
