import type { GameSettings, Quality } from '../game/Game';
import type { TimeOfDay } from '../game/scenery';
import type { AircraftId } from '../game/aircraft';
import { SPECS } from '../game/aircraft';

function Seg<T extends string>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { id: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <div className="flex rounded-xl bg-black/30 p-1">
      {options.map((o) => (
        <button
          key={o.id}
          onClick={() => onChange(o.id)}
          className={`flex-1 rounded-lg px-2 py-2 text-sm font-semibold transition-colors ${
            value === o.id ? 'bg-sky-500 text-white shadow' : 'text-white/70 active:bg-white/10'
          }`}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Check({ label, on, onChange }: { label: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      className="flex items-center gap-2 rounded-xl bg-black/25 px-3 py-2.5 text-left text-sm font-medium text-white active:bg-black/40"
    >
      <span
        className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border-2 text-xs ${
          on ? 'border-emerald-400 bg-emerald-500' : 'border-white/40'
        }`}
      >
        {on ? '✓' : ''}
      </span>
      {label}
    </button>
  );
}

function PlaneIcon({ id }: { id: AircraftId }) {
  return id === 'skyhawk' ? (
    <svg viewBox="0 0 120 60" className="h-12 w-24">
      <path d="M8 32 L48 28 L52 8 L58 8 L60 28 L100 30 L112 22 L114 26 L104 36 L58 38 L52 54 L46 54 L44 38 L8 36Z" fill="#f4f4f1" stroke="#b22" strokeWidth="1.5" />
      <circle cx="8" cy="34" r="5" fill="#333" />
    </svg>
  ) : (
    <svg viewBox="0 0 120 60" className="h-12 w-24">
      <path d="M4 30 L60 24 L90 8 L96 8 L88 26 L112 30 L88 34 L96 52 L90 52 L60 36Z" fill="#9aa5b1" stroke="#e5e7eb" strokeWidth="1.5" />
      <path d="M112 30 L120 28 L120 32Z" fill="#ffa040" />
    </svg>
  );
}

export default function Menu({
  settings,
  onChange,
  onStart,
}: {
  settings: GameSettings;
  onChange: (s: GameSettings) => void;
  onStart: () => void;
}) {
  const set = <K extends keyof GameSettings>(k: K, v: GameSettings[K]) => onChange({ ...settings, [k]: v });
  return (
    <div className="relative h-full w-full overflow-y-auto bg-gradient-to-b from-sky-500 via-sky-700 to-slate-900 text-white">
      {/* decorative clouds */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-10 left-[8%] h-24 w-72 rounded-full bg-white/20 blur-2xl" />
        <div className="absolute top-28 right-[6%] h-20 w-80 rounded-full bg-white/15 blur-2xl" />
        <div className="absolute bottom-0 h-40 w-full bg-gradient-to-t from-emerald-900/70 to-transparent" />
      </div>

      <div className="relative mx-auto flex min-h-full w-full max-w-3xl flex-col gap-4 p-4 sm:p-6">
        <header className="pt-2 text-center">
          <div className="text-xs font-bold tracking-[0.4em] text-sky-100/80">OPEN-WORLD FLIGHT SIMULATOR</div>
          <h1 className="mt-1 text-5xl font-black tracking-tight drop-shadow-lg sm:text-6xl">
            SKY<span className="text-amber-300">BOUND</span>
          </h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-sky-50/90">
            An endless procedurally generated planet — coastlines, mountains, forests, towns and airports. Take off from
            anywhere and fly forever.
          </p>
        </header>

        <section className="grid gap-3 sm:grid-cols-2">
          {(Object.keys(SPECS) as AircraftId[]).map((id) => {
            const s = SPECS[id];
            const on = settings.aircraft === id;
            return (
              <button
                key={id}
                onClick={() => set('aircraft', id)}
                className={`flex items-center gap-3 rounded-2xl border-2 p-3 text-left transition-all ${
                  on ? 'border-amber-300 bg-white/20 shadow-lg' : 'border-white/20 bg-black/20 active:bg-black/30'
                }`}
              >
                <PlaneIcon id={id} />
                <div>
                  <div className="font-bold">{s.name}</div>
                  <div className="text-xs leading-snug text-white/75">{s.tagline}</div>
                  <div className="mt-1 text-[10px] font-semibold text-sky-200">
                    Stall {s.stallKt} kt · Max {s.maxKt} kt
                  </div>
                </div>
              </button>
            );
          })}
        </section>

        <section className="grid gap-3 rounded-2xl bg-black/25 p-3 backdrop-blur-sm sm:grid-cols-2">
          <div>
            <div className="mb-1 text-xs font-bold tracking-wider text-white/70">TIME OF DAY</div>
            <Seg<TimeOfDay>
              value={settings.time}
              onChange={(v) => set('time', v)}
              options={[
                { id: 'day', label: '☀ Day' },
                { id: 'sunset', label: '🌇 Sunset' },
                { id: 'night', label: '🌙 Night' },
              ]}
            />
          </div>
          <div>
            <div className="mb-1 text-xs font-bold tracking-wider text-white/70">GRAPHICS</div>
            <Seg<Quality>
              value={settings.quality}
              onChange={(v) => set('quality', v)}
              options={[
                { id: 'low', label: 'Low' },
                { id: 'medium', label: 'Medium' },
                { id: 'high', label: 'High' },
              ]}
            />
          </div>
          <Check label="Flight assist (auto-level, stall guard)" on={settings.assist} onChange={(v) => set('assist', v)} />
          <Check label="Start in the air" on={settings.startInAir} onChange={(v) => set('startInAir', v)} />
          <Check label="Invert pitch (drag up = nose up)" on={settings.invertY} onChange={(v) => set('invertY', v)} />
          <Check label="Sound" on={settings.sound} onChange={(v) => set('sound', v)} />
        </section>

        <button
          onClick={onStart}
          className="rounded-2xl bg-gradient-to-r from-amber-400 to-orange-500 py-4 text-xl font-black tracking-wide text-slate-900 shadow-xl active:scale-[0.98]"
        >
          ✈ START FLIGHT
        </button>

        <section className="rounded-2xl bg-black/25 p-3 text-xs leading-relaxed text-white/85 backdrop-blur-sm">
          <div className="mb-1 font-bold tracking-wider text-white/70">CONTROLS</div>
          <div className="grid gap-x-6 gap-y-1 sm:grid-cols-2">
            <div>
              <b>Left thumb</b> — floating stick: pitch &amp; roll
            </div>
            <div>
              <b>Right slider</b> — throttle
            </div>
            <div>
              <b>⟲ ⟳</b> — rudder (steers on the ground)
            </div>
            <div>
              <b>GEAR / FLAPS / VIEW</b> — top-right buttons
            </div>
            <div className="sm:col-span-2 text-white/70">
              Keyboard: W/S pitch · A/D roll · Q/E rudder · Shift/Ctrl throttle · G gear · F flaps · B brake · C view · P pause · R reset
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
