import * as THREE from 'three';

export type AircraftId = 'skyhawk' | 'falcon';

export interface AircraftSpec {
  id: AircraftId;
  name: string;
  tagline: string;
  jet: boolean;
  wl: number; // wing loading kg/m2
  cl0: number;
  clAlpha: number;
  stallAlpha: number;
  alphaTrim: number;
  cd0: number;
  k: number;
  thrust: number; // m/s2 at static, full throttle
  vTh: number; // speed where prop thrust falls to 0
  rollRate: number;
  pitchRate: number;
  yawRate: number;
  vRef: number;
  gearH: number;
  bellyH: number;
  vRotate: number;
  maxSink: number;
  stallKt: number;
  maxKt: number;
  camDist: number;
  camHeight: number;
  cockpit: [number, number, number];
  brakeDecel: number;
}

export const SPECS: Record<AircraftId, AircraftSpec> = {
  skyhawk: {
    id: 'skyhawk',
    name: 'Skyhawk 172',
    tagline: 'Forgiving single-engine prop. Perfect for sightseeing & learning to land.',
    jet: false,
    wl: 62,
    cl0: 0.25,
    clAlpha: 5.0,
    stallAlpha: 0.27,
    alphaTrim: 0.04,
    cd0: 0.03,
    k: 0.055,
    thrust: 4.8,
    vTh: 105,
    rollRate: 1.5,
    pitchRate: 0.75,
    yawRate: 0.45,
    vRef: 42,
    gearH: 1.3,
    bellyH: 0.65,
    vRotate: 25,
    maxSink: 5.5,
    stallKt: 48,
    maxKt: 160,
    camDist: 14,
    camHeight: 3.6,
    cockpit: [0, 0.85, -1.3],
    brakeDecel: 0.45,
  },
  falcon: {
    id: 'falcon',
    name: 'Falcon F-16',
    tagline: 'Supersonic-class fighter jet. Fast, agile, unforgiving.',
    jet: true,
    wl: 290,
    cl0: 0.12,
    clAlpha: 4.2,
    stallAlpha: 0.4,
    alphaTrim: 0.03,
    cd0: 0.034,
    k: 0.12,
    thrust: 8.2,
    vTh: 1e9,
    rollRate: 3.2,
    pitchRate: 1.1,
    yawRate: 0.5,
    vRef: 120,
    gearH: 2.0,
    bellyH: 0.9,
    vRotate: 75,
    maxSink: 6.5,
    stallKt: 135,
    maxKt: 750,
    camDist: 24,
    camHeight: 5,
    cockpit: [0, 1.1, -3.8],
    brakeDecel: 0.35,
  },
};

export interface AircraftModel {
  group: THREE.Group;
  prop?: THREE.Object3D;
  propDisc?: THREE.Mesh;
  flame?: THREE.Mesh;
  gear: THREE.Group;
  lights: THREE.Mesh[];
  strobe: THREE.Mesh;
}

function std(color: number, rough = 0.5, metal = 0.1) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
}

function addLights(group: THREE.Group, wing: number, z: number, y = 0.7): { lights: THREE.Mesh[]; strobe: THREE.Mesh } {
  const gm = new THREE.SphereGeometry(0.14, 8, 6);
  const red = new THREE.Mesh(gm, new THREE.MeshBasicMaterial({ color: 0xff2a2a }));
  red.position.set(-wing, y, z);
  const green = new THREE.Mesh(gm, new THREE.MeshBasicMaterial({ color: 0x2aff5a }));
  green.position.set(wing, y, z);
  const strobe = new THREE.Mesh(gm, new THREE.MeshBasicMaterial({ color: 0xffffff }));
  strobe.scale.setScalar(1.4);
  strobe.position.set(0, y + 1.6, z + 5);
  group.add(red, green, strobe);
  return { lights: [red, green], strobe };
}

function wheel(r: number, w: number, mat: THREE.Material) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, w, 14), mat);
  m.rotation.z = Math.PI / 2;
  return m;
}

export function buildSkyhawk(): AircraftModel {
  const g = new THREE.Group();
  const white = std(0xf1f1ee, 0.45, 0.15);
  const red = std(0xc22a2a, 0.5, 0.1);
  const dark = std(0x1c2530, 0.3, 0.3);
  const glass = new THREE.MeshStandardMaterial({ color: 0x1b3550, roughness: 0.05, metalness: 0.6 });
  const tire = std(0x151515, 0.9, 0);
  const metal = std(0x8a8d92, 0.4, 0.7);

  // fuselage: forward barrel + tail cone
  const front = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.78, 3.0, 16), white);
  front.rotation.x = Math.PI / 2;
  front.position.set(0, 0, -1.0);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.76, 5.4, 16), white);
  tail.rotation.x = Math.PI / 2;
  tail.position.set(0, 0.08, 3.1);
  const cowl = new THREE.Mesh(new THREE.CylinderGeometry(0.66, 0.72, 1.1, 16), white);
  cowl.rotation.x = Math.PI / 2;
  cowl.position.set(0, -0.05, -2.9);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.66, 16, 10, 0, Math.PI * 2, 0, Math.PI / 2), white);
  nose.rotation.x = -Math.PI / 2;
  nose.position.set(0, -0.05, -3.45);
  const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.58, 0.14, 4.6), red);
  stripe.position.set(0, 0.1, 0.9);
  // cabin windows
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.35, 0.5, 1.9), glass);
  cabin.position.set(0, 0.55, -0.7);
  const roofc = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.12, 2.0), white);
  roofc.position.set(0, 0.86, -0.4);
  // wing
  const wing = new THREE.Mesh(new THREE.BoxGeometry(11, 0.14, 1.7), white);
  wing.position.set(0, 0.95, -0.55);
  const wingTipL = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.16, 1.6), red);
  wingTipL.position.set(-5.4, 0.95, -0.55);
  const wingTipR = wingTipL.clone();
  wingTipR.position.x = 5.4;
  const strutL = new THREE.Mesh(new THREE.BoxGeometry(0.07, 1.9, 0.12), white);
  strutL.position.set(-2.1, 0.0, -0.6);
  strutL.rotation.z = -0.62;
  const strutR = strutL.clone();
  strutR.position.x = 2.1;
  strutR.rotation.z = 0.62;
  // empennage
  const hstab = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.1, 1.0), white);
  hstab.position.set(0, 0.3, 5.3);
  const vstab = new THREE.Mesh(new THREE.BoxGeometry(0.1, 1.5, 1.3), white);
  vstab.position.set(0, 1.0, 5.1);
  vstab.rotation.x = -0.25;
  const vtop = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.5, 0.9), red);
  vtop.position.set(0, 1.55, 5.3);
  vtop.rotation.x = -0.25;
  g.add(front, tail, cowl, nose, stripe, cabin, roofc, wing, wingTipL, wingTipR, strutL, strutR, hstab, vstab, vtop);

  // propeller
  const prop = new THREE.Group();
  prop.position.set(0, -0.05, -3.55);
  const bladeGeo = new THREE.BoxGeometry(0.16, 2.1, 0.04);
  const b1 = new THREE.Mesh(bladeGeo, dark);
  const b2 = new THREE.Mesh(bladeGeo, dark);
  b2.rotation.z = Math.PI / 2;
  prop.add(b1, b2);
  const spinner = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.5, 12), red);
  spinner.rotation.x = -Math.PI / 2;
  spinner.position.z = -0.2;
  g.add(spinner);
  spinner.position.set(0, -0.05, -3.8);
  const disc = new THREE.Mesh(
    new THREE.CircleGeometry(1.05, 24),
    new THREE.MeshBasicMaterial({ color: 0x222222, transparent: true, opacity: 0, side: THREE.DoubleSide, depthWrite: false }),
  );
  disc.position.set(0, -0.05, -3.6);
  g.add(prop, disc);

  // landing gear
  const gear = new THREE.Group();
  const noseStrut = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.0, 6), metal);
  noseStrut.position.set(0, -0.8, -2.2);
  const nw = wheel(0.22, 0.14, tire);
  nw.position.set(0, -1.08, -2.2);
  gear.add(noseStrut, nw);
  for (const sx of [-1, 1]) {
    const st = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.8, 0.14), metal);
    st.position.set(sx * 1.0, -0.8, -0.25);
    st.rotation.z = sx * 0.4;
    const w = wheel(0.27, 0.17, tire);
    w.position.set(sx * 1.2, -1.03, -0.25);
    const pant = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.4, 0.8), white);
    pant.position.set(sx * 1.2, -0.95, -0.25);
    gear.add(st, w, pant);
  }
  g.add(gear);
  const { lights, strobe } = addLights(g, 5.45, -0.5, 0.95);
  return { group: g, prop, propDisc: disc, gear, lights, strobe };
}

function wingShape(pts: [number, number][]) {
  const s = new THREE.Shape();
  s.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length; i++) s.lineTo(pts[i][0], pts[i][1]);
  s.closePath();
  const geo = new THREE.ExtrudeGeometry(s, { depth: 0.14, bevelEnabled: false });
  geo.rotateX(Math.PI / 2);
  return geo;
}

export function buildFalcon(): AircraftModel {
  const g = new THREE.Group();
  const grey = std(0x8d97a2, 0.4, 0.4);
  const darkgrey = std(0x59616b, 0.45, 0.4);
  const glass = new THREE.MeshStandardMaterial({
    color: 0x8a6a30,
    roughness: 0.05,
    metalness: 0.9,
    emissive: 0x221808,
  });
  const tire = std(0x151515, 0.9, 0);
  const metal = std(0xa0a4aa, 0.4, 0.7);

  // fuselage
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 1.05, 8.5, 16), grey);
  body.rotation.x = Math.PI / 2;
  body.position.set(0, 0, 1.3);
  const noseCone = new THREE.Mesh(new THREE.ConeGeometry(0.85, 4.2, 16), grey);
  noseCone.rotation.x = -Math.PI / 2;
  noseCone.position.set(0, 0, -5.15);
  const tailEng = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.8, 2.4, 16), darkgrey);
  tailEng.rotation.x = Math.PI / 2;
  tailEng.position.set(0, 0, 6.7);
  const nozzle = new THREE.Mesh(new THREE.CylinderGeometry(0.72, 0.62, 0.6, 16, 1, true), std(0x2c2c30, 0.6, 0.8));
  nozzle.rotation.x = Math.PI / 2;
  nozzle.position.set(0, 0, 8.2);
  const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.78, 16, 12), glass);
  canopy.scale.set(0.85, 0.85, 3.0);
  canopy.position.set(0, 0.7, -1.9);
  const intake = new THREE.Mesh(new THREE.CylinderGeometry(0.62, 0.72, 2.6, 14, 1, true), std(0x15171a, 0.8, 0.2));
  intake.rotation.x = Math.PI / 2;
  intake.position.set(0, -0.95, -0.4);
  const intakeBody = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.8, 3.6), grey);
  intakeBody.position.set(0, -0.62, 0.4);
  g.add(body, noseCone, tailEng, nozzle, canopy, intake, intakeBody);

  // wings (right + mirrored left)
  const wgeo = wingShape([
    [0.6, 1.0],
    [4.6, 3.2],
    [4.6, 4.3],
    [0.8, 4.6],
  ]);
  const wR = new THREE.Mesh(wgeo, grey);
  wR.position.set(0.2, -0.1, -0.5);
  const wL = new THREE.Mesh(wgeo, grey);
  wL.scale.x = -1;
  wL.position.set(-0.2, -0.1, -0.5);
  // tip missiles
  const msl = new THREE.CylinderGeometry(0.11, 0.11, 3.0, 8);
  const mR = new THREE.Mesh(msl, std(0xe8e8e8, 0.4, 0.3));
  mR.rotation.x = Math.PI / 2;
  mR.position.set(4.85, -0.06, 3.0);
  const mL = mR.clone();
  mL.position.x = -4.85;
  // horizontal stabilisers
  const sgeo = wingShape([
    [0.5, 0],
    [2.6, 1.3],
    [2.6, 2.0],
    [0.5, 2.0],
  ]);
  const sR = new THREE.Mesh(sgeo, darkgrey);
  sR.position.set(0.7, -0.05, 6.0);
  const sL = new THREE.Mesh(sgeo, darkgrey);
  sL.scale.x = -1;
  sL.position.set(-0.7, -0.05, 6.0);
  // vertical fin
  const finGeo = new THREE.ExtrudeGeometry(
    (() => {
      const s = new THREE.Shape();
      s.moveTo(0, 0);
      s.lineTo(3.4, 0);
      s.lineTo(2.8, 2.4);
      s.lineTo(1.6, 2.4);
      s.closePath();
      return s;
    })(),
    { depth: 0.12, bevelEnabled: false },
  );
  // shape x = along body (aft = +x -> +z), y = up
  finGeo.rotateY(-Math.PI / 2); // x -> z
  const fin2 = new THREE.Mesh(finGeo, grey);
  fin2.position.set(-0.06, 0.6, 3.2);
  g.add(wR, wL, mR, mL, sR, sL, fin2);

  // afterburner flame
  const flame = new THREE.Mesh(
    new THREE.ConeGeometry(0.55, 4.5, 12, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0xffa040,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
    }),
  );
  flame.rotation.x = Math.PI / 2; // tip points aft (+z)
  flame.position.set(0, 0, 10.4);
  flame.visible = false;
  g.add(flame);

  // gear
  const gear = new THREE.Group();
  const ns = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 1.2, 6), metal);
  ns.position.set(0, -1.3, -3.2);
  const nw = wheel(0.3, 0.16, tire);
  nw.position.set(0, -1.7, -3.2);
  gear.add(ns, nw);
  for (const sx of [-1, 1]) {
    const st = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.2, 6), metal);
    st.position.set(sx * 1.1, -1.3, 1.6);
    const w = wheel(0.38, 0.22, tire);
    w.position.set(sx * 1.1, -1.65, 1.6);
    gear.add(st, w);
  }
  g.add(gear);

  const { lights, strobe } = addLights(g, 4.9, 3.0, -0.06);
  strobe.position.set(0, 3.2, 7.5);
  // shift so the wing / centre of lift sits near the origin
  g.position.z = -2.0;
  const root = new THREE.Group();
  root.add(g);
  return { group: root, gear, lights, strobe, flame };
}
