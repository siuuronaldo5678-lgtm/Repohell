import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { CHUNK, getHeight, zonesNear, forestMask, type Zone } from './world';
import { fbm, noise2, hash, smoothstep, clamp } from './noise';

const LOD_SEG = [64, 32, 16];
const UV_SCALE = 70;

const C = (hex: number) => new THREE.Color(hex);
const sandC = C(0xd9c9a2);
const deepC = C(0x0a2a48);
const shallowC = C(0x6fa6a0);
const grassA = C(0x5c8236);
const grassB = C(0x7a8f3e);
const forestC = C(0x2c4a24);
const farmA = C(0xa3a552);
const farmB = C(0x7f9a45);
const rockC = C(0x7a7269);
const darkRockC = C(0x56504b);
const snowC = C(0xf0f4f8);
const townC = C(0x8d8c8a);
const aptC = C(0x6f9a40);

export interface TerrainMaterials {
  ground: THREE.MeshLambertMaterial;
  tree: THREE.MeshLambertMaterial;
  building: THREE.MeshLambertMaterial;
}

function makeDetailTexture(): THREE.Texture {
  const s = 256;
  const cv = document.createElement('canvas');
  cv.width = cv.height = s;
  const g = cv.getContext('2d')!;
  const img = g.createImageData(s, s);
  for (let y = 0; y < s; y++)
    for (let x = 0; x < s; x++) {
      // tileable-ish value using periodic noise via blending
      const n =
        0.5 +
        0.5 *
          (Math.sin(x * 0.19) * Math.sin(y * 0.23) * 0.3 +
            (hash(x, y, 1) - 0.5) * 0.9 +
            Math.sin((x + y) * 0.07) * 0.2);
      const v = 205 + n * 50;
      const i = (y * s + x) * 4;
      img.data[i] = img.data[i + 1] = img.data[i + 2] = clamp(v, 0, 255);
      img.data[i + 3] = 255;
    }
  g.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(cv);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function makeTreeGeometry(): THREE.BufferGeometry {
  const trunk = new THREE.CylinderGeometry(0.28, 0.4, 3, 5);
  trunk.translate(0, 1.5, 0);
  const c1 = new THREE.ConeGeometry(2.9, 6, 6);
  c1.translate(0, 5.2, 0);
  const c2 = new THREE.ConeGeometry(2.1, 5, 6);
  c2.translate(0, 8.4, 0);
  const parts: [THREE.BufferGeometry, THREE.Color][] = [
    [trunk, new THREE.Color(0x4a3524)],
    [c1, new THREE.Color(0x3e7a35)],
    [c2, new THREE.Color(0x4a8a3c)],
  ];
  const geos = parts.map(([g, col]) => {
    const n = g.getAttribute('position').count;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      arr[i * 3] = col.r;
      arr[i * 3 + 1] = col.g;
      arr[i * 3 + 2] = col.b;
    }
    g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
    const ng = g.toNonIndexed();
    ng.deleteAttribute('uv');
    return ng;
  });
  return mergeGeometries(geos)!;
}

function makeBoxGeometry(): THREE.BufferGeometry {
  const g = new THREE.BoxGeometry(1, 1, 1);
  g.translate(0, 0.5, 0);
  return g;
}

export function createMaterials(): TerrainMaterials {
  return {
    ground: new THREE.MeshLambertMaterial({
      vertexColors: true,
      map: makeDetailTexture(),
      side: THREE.DoubleSide,
    }),
    tree: new THREE.MeshLambertMaterial({ vertexColors: true }),
    building: new THREE.MeshLambertMaterial({ color: 0xffffff, emissive: 0xffb866, emissiveIntensity: 0 }),
  };
}

const tmpColor = new THREE.Color();
const tmpColor2 = new THREE.Color();

function terrainColor(
  wx: number,
  wz: number,
  h: number,
  slope: number,
  zones: Zone[],
  out: THREE.Color,
): void {
  const n1 = fbm(wx / 900, wz / 900, 2);
  const n2 = noise2(wx / 55, wz / 55);
  if (h <= 0) {
    const t = clamp(-h / 55, 0, 1);
    out.copy(shallowC).lerp(deepC, Math.pow(t, 0.5));
    if (h > -3) out.lerp(sandC, 0.7);
    return;
  }
  let town = 0;
  let apt = 0;
  for (let k = 0; k < zones.length; k++) {
    const z = zones[k];
    const d = Math.hypot(wx - z.x, wz - z.z);
    if (z.kind === 'town') town = Math.max(town, 1 - smoothstep(z.rFlat * 0.5, z.rFlat * 0.95, d));
    else apt = Math.max(apt, 1 - smoothstep(z.rFlat * 0.6, z.rFlat * 1.3, d));
  }
  // base vegetation
  out.copy(grassA).lerp(grassB, smoothstep(-0.2, 0.25, n1));
  const forest = forestMask(wx, wz, h);
  out.lerp(forestC, forest * 0.85);
  // farm fields
  const fieldN = fbm(wx / 450 + 9, wz / 450 - 3, 2);
  if (forest < 0.3 && fieldN > 0.04 && h < 500) {
    const stripe = Math.sin((wx * 0.7 + wz * 0.35) / 14 + Math.floor(fieldN * 40)) * 0.5 + 0.5;
    tmpColor.copy(farmA).lerp(farmB, (Math.floor(fieldN * 25) % 3) / 2);
    tmpColor.multiplyScalar(0.9 + stripe * 0.12);
    out.lerp(tmpColor, smoothstep(0.04, 0.12, fieldN) * 0.85);
  }
  // beach
  if (h < 5) out.lerp(sandC, (1 - h / 5) * (slope < 0.3 ? 1 : 0.4));
  // rock / snow
  const rockT = Math.max(smoothstep(800, 1150, h + n1 * 160), smoothstep(0.16, 0.38, slope));
  tmpColor2.copy(rockC).lerp(darkRockC, smoothstep(-0.3, 0.4, n2));
  out.lerp(tmpColor2, rockT);
  const snow = smoothstep(1350, 1650, h + n1 * 220) * (1 - smoothstep(0.35, 0.7, slope) * 0.8);
  out.lerp(snowC, snow);
  if (apt > 0) out.lerp(aptC, apt * 0.8);
  if (town > 0) out.lerp(townC, town * 0.9);
  const v = 1 + n2 * 0.07;
  out.r *= v;
  out.g *= v;
  out.b *= v;
}

interface Chunk {
  group: THREE.Group;
  lod: number;
  cx: number;
  cz: number;
  geos: THREE.BufferGeometry[];
  inst: THREE.InstancedMesh[];
}

export class Terrain {
  scene: THREE.Scene;
  mats: TerrainMaterials;
  chunks = new Map<string, Chunk>();
  radius: number;
  treeGeo = makeTreeGeometry();
  boxGeo = makeBoxGeometry();
  pendingCount = 0;
  nearPending = 0;

  constructor(scene: THREE.Scene, radius: number) {
    this.scene = scene;
    this.radius = radius;
    this.mats = createMaterials();
  }

  private lodFor(dist: number) {
    return dist <= 1 ? 0 : dist <= 2 ? 1 : 2;
  }

  /** Streams chunks around (px,pz). Returns number of chunks built. */
  update(px: number, pz: number, budgetMs: number): number {
    const cx = Math.floor(px / CHUNK);
    const cz = Math.floor(pz / CHUNK);
    const R = this.radius;
    const wanted: { cx: number; cz: number; dist: number; d2: number; lod: number }[] = [];
    for (let dx = -R; dx <= R; dx++)
      for (let dz = -R; dz <= R; dz++) {
        const dist = Math.max(Math.abs(dx), Math.abs(dz));
        wanted.push({ cx: cx + dx, cz: cz + dz, dist, d2: dx * dx + dz * dz, lod: this.lodFor(dist) });
      }
    // remove far chunks
    for (const [key, ch] of this.chunks) {
      if (Math.max(Math.abs(ch.cx - cx), Math.abs(ch.cz - cz)) > R + 1) {
        this.disposeChunk(ch);
        this.chunks.delete(key);
      }
    }
    const todo = wanted.filter((w) => {
      const ch = this.chunks.get(w.cx + ',' + w.cz);
      return !ch || ch.lod !== w.lod;
    });
    todo.sort((a, b) => a.d2 - b.d2);
    this.pendingCount = todo.length;
    this.nearPending = todo.filter((t) => t.dist <= 2).length;
    const start = performance.now();
    let built = 0;
    for (const w of todo) {
      const key = w.cx + ',' + w.cz;
      const old = this.chunks.get(key);
      const ch = this.build(w.cx, w.cz, w.lod);
      if (old) this.disposeChunk(old);
      this.chunks.set(key, ch);
      built++;
      if (performance.now() - start > budgetMs) break;
    }
    return built;
  }

  private disposeChunk(ch: Chunk) {
    this.scene.remove(ch.group);
    ch.geos.forEach((g) => g.dispose());
    ch.inst.forEach((m) => m.dispose());
  }

  setNight(n: number) {
    this.mats.building.emissiveIntensity = n * 0.55;
  }

  private build(cx: number, cz: number, lod: number): Chunk {
    const n = LOD_SEG[lod];
    const step = CHUNK / n;
    const x0 = cx * CHUNK;
    const z0 = cz * CHUNK;
    const zones = zonesNear(x0 + CHUNK / 2, z0 + CHUNK / 2, CHUNK * 0.75);
    const W = n + 3;
    const H = new Float32Array(W * W);
    for (let j = 0; j < W; j++)
      for (let i = 0; i < W; i++) H[j * W + i] = getHeight(x0 + (i - 1) * step, z0 + (j - 1) * step, zones);

    const nv = (n + 1) * (n + 1);
    const ns = 4 * (n + 1);
    const pos = new Float32Array((nv + ns) * 3);
    const nor = new Float32Array((nv + ns) * 3);
    const col = new Float32Array((nv + ns) * 3);
    const uv = new Float32Array((nv + ns) * 2);
    const color = new THREE.Color();
    for (let j = 0; j <= n; j++)
      for (let i = 0; i <= n; i++) {
        const idx = j * (n + 1) + i;
        const h = H[(j + 1) * W + (i + 1)];
        const hx = H[(j + 1) * W + (i + 2)] - H[(j + 1) * W + i];
        const hz = H[(j + 2) * W + (i + 1)] - H[j * W + (i + 1)];
        let nx = -hx / (2 * step);
        let nz = -hz / (2 * step);
        const l = Math.sqrt(nx * nx + 1 + nz * nz);
        nx /= l;
        nz /= l;
        const ny = 1 / l;
        pos[idx * 3] = i * step;
        pos[idx * 3 + 1] = h;
        pos[idx * 3 + 2] = j * step;
        nor[idx * 3] = nx;
        nor[idx * 3 + 1] = ny;
        nor[idx * 3 + 2] = nz;
        const wx = x0 + i * step;
        const wz = z0 + j * step;
        terrainColor(wx, wz, h, 1 - ny, zones, color);
        col[idx * 3] = color.r;
        col[idx * 3 + 1] = color.g;
        col[idx * 3 + 2] = color.b;
        uv[idx * 2] = wx / UV_SCALE;
        uv[idx * 2 + 1] = wz / UV_SCALE;
      }
    const idxs: number[] = [];
    for (let j = 0; j < n; j++)
      for (let i = 0; i < n; i++) {
        const a = j * (n + 1) + i;
        const b = a + 1;
        const c = a + (n + 1);
        const d = c + 1;
        idxs.push(a, c, b, b, c, d);
      }
    // skirts to hide LOD cracks
    const depth = 40 + lod * 40;
    const edges: number[][] = [[], [], [], []];
    for (let k = 0; k <= n; k++) {
      edges[0].push(k); // top row (j=0)
      edges[1].push(n * (n + 1) + k); // bottom row
      edges[2].push(k * (n + 1)); // left col
      edges[3].push(k * (n + 1) + n); // right col
    }
    let sv = nv;
    edges.forEach((edge) => {
      const base = sv;
      edge.forEach((src, k) => {
        const o = (base + k) * 3;
        pos[o] = pos[src * 3];
        pos[o + 1] = pos[src * 3 + 1] - depth;
        pos[o + 2] = pos[src * 3 + 2];
        nor[o] = nor[src * 3];
        nor[o + 1] = nor[src * 3 + 1];
        nor[o + 2] = nor[src * 3 + 2];
        col[o] = col[src * 3];
        col[o + 1] = col[src * 3 + 1];
        col[o + 2] = col[src * 3 + 2];
        uv[(base + k) * 2] = uv[src * 2];
        uv[(base + k) * 2 + 1] = uv[src * 2 + 1];
      });
      for (let k = 0; k < n; k++) {
        const a = edge[k];
        const b = edge[k + 1];
        idxs.push(a, b, base + k, b, base + k + 1, base + k);
      }
      sv += n + 1;
    });

    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(col, 3));
    geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    geo.setIndex(idxs);
    geo.computeBoundingSphere();
    const mesh = new THREE.Mesh(geo, this.mats.ground);
    mesh.position.set(x0, 0, z0);
    const group = new THREE.Group();
    group.add(mesh);
    const geos: THREE.BufferGeometry[] = [geo];
    const inst: THREE.InstancedMesh[] = [];

    if (lod <= 1) {
      const trees = this.buildTrees(x0, z0, lod, zones);
      if (trees) {
        group.add(trees);
        inst.push(trees);
      }
    }
    if (lod <= 1) {
      const b = this.buildBuildings(x0, z0, zones);
      if (b) {
        group.add(b);
        inst.push(b);
      }
    }
    this.scene.add(group);
    return { group, lod, cx, cz, geos, inst };
  }

  private buildTrees(x0: number, z0: number, lod: number, zones: Zone[]): THREE.InstancedMesh | null {
    const spacing = lod === 0 ? 38 : 76;
    const sc = lod === 0 ? 1 : 1.9;
    const cells = Math.floor(CHUNK / spacing);
    const mats: THREE.Matrix4[] = [];
    const cols: number[] = [];
    const seedI = Math.floor(x0 / CHUNK);
    const seedJ = Math.floor(z0 / CHUNK);
    const q = new THREE.Quaternion();
    const e = new THREE.Euler();
    const p = new THREE.Vector3();
    const s = new THREE.Vector3();
    const c = new THREE.Color();
    for (let j = 0; j < cells; j++)
      for (let i = 0; i < cells; i++) {
        const k = i + j * cells;
        const wx = x0 + (i + hash(seedI * 97 + i, seedJ * 57 + j, 3)) * spacing;
        const wz = z0 + (j + hash(seedI * 97 + i, seedJ * 57 + j, 4)) * spacing;
        // skip zones (towns / airports)
        let blocked = false;
        for (let z = 0; z < zones.length; z++) {
          const zn = zones[z];
          if (Math.hypot(wx - zn.x, wz - zn.z) < zn.rFlat * (zn.kind === 'airport' ? 1.15 : 1.0)) {
            blocked = true;
            break;
          }
        }
        if (blocked) continue;
        const h = getHeight(wx, wz, zones);
        const f = forestMask(wx, wz, h);
        // sparse single trees outside forest
        const rnd = hash(seedI * 131 + i, seedJ * 71 + j, 5);
        const dens = f * 0.95 + (h > 8 && h < 600 ? 0.03 : 0);
        if (rnd > dens) continue;
        // skip steep terrain
        const hx = getHeight(wx + 4, wz, zones) - h;
        if (Math.abs(hx) > 2.2) continue;
        const scale = (0.75 + hash(k, seedI + seedJ, 6) * 0.8) * sc;
        e.set(0, hash(k, seedJ, 7) * 6.28, 0);
        q.setFromEuler(e);
        p.set(wx, h - 0.3, wz);
        s.set(scale, scale * (0.9 + hash(k, seedI, 8) * 0.4), scale);
        mats.push(new THREE.Matrix4().compose(p, q, s));
        const shade = 0.75 + hash(k, seedJ, 9) * 0.5;
        c.setRGB(shade, shade * (0.95 + hash(k, seedI, 10) * 0.12), shade * 0.95);
        cols.push(c.r, c.g, c.b);
      }
    if (mats.length === 0) return null;
    const im = new THREE.InstancedMesh(this.treeGeo, this.mats.tree, mats.length);
    for (let i = 0; i < mats.length; i++) {
      im.setMatrixAt(i, mats[i]);
      im.setColorAt(i, c.setRGB(cols[i * 3], cols[i * 3 + 1], cols[i * 3 + 2]));
    }
    im.instanceMatrix.needsUpdate = true;
    return im;
  }

  private buildBuildings(x0: number, z0: number, zones: Zone[]): THREE.InstancedMesh | null {
    const towns = zones.filter((z) => z.kind === 'town');
    if (towns.length === 0) return null;
    const GRID = 48;
    const items: { m: THREE.Matrix4; c: THREE.Color }[] = [];
    const p = new THREE.Vector3();
    const q = new THREE.Quaternion();
    const s = new THREE.Vector3();
    const palette = [0xd8d2c4, 0xc9c3b6, 0xb7b2a8, 0xe3ddd0, 0xa8a49c, 0xb9876a, 0x9aa5ad, 0xcfc7b5];
    for (const t of towns) {
      const R = t.rFlat * 0.92;
      const minI = Math.max(Math.floor((x0 - t.x) / GRID), Math.floor(-R / GRID));
      const maxI = Math.min(Math.floor((x0 + CHUNK - t.x) / GRID), Math.ceil(R / GRID));
      const minJ = Math.max(Math.floor((z0 - t.z) / GRID), Math.floor(-R / GRID));
      const maxJ = Math.min(Math.floor((z0 + CHUNK - t.z) / GRID), Math.ceil(R / GRID));
      for (let i = minI; i <= maxI; i++)
        for (let j = minJ; j <= maxJ; j++) {
          const bx = t.x + (i + 0.5) * GRID;
          const bz = t.z + (j + 0.5) * GRID;
          if (bx < x0 || bx >= x0 + CHUNK || bz < z0 || bz >= z0 + CHUNK) continue;
          const d = Math.hypot(bx - t.x, bz - t.z);
          if (d > R) continue;
          const dn = d / R;
          const r1 = hash(i + t.seed, j, 31);
          if (r1 > 0.92 - dn * 0.5) continue;
          const r2 = hash(i + t.seed, j, 32);
          const r3 = hash(i + t.seed, j, 33);
          const w = 20 + r2 * 16;
          const l = 20 + r3 * 16;
          const centerBoost = Math.pow(1 - dn, 2.2);
          const hgt = 6 + r2 * 8 + centerBoost * r3 * 70 * (hash(i, j + t.seed, 34) > 0.6 ? 1 : 0.3);
          p.set(bx, t.elev, bz);
          q.setFromEuler(new THREE.Euler(0, 0, 0));
          s.set(w, hgt, l);
          items.push({
            m: new THREE.Matrix4().compose(p, q, s),
            c: new THREE.Color(palette[Math.floor(hash(i + t.seed, j, 35) * palette.length)]),
          });
        }
    }
    if (items.length === 0) return null;
    const im = new THREE.InstancedMesh(this.boxGeo, this.mats.building, items.length);
    items.forEach((it, i) => {
      im.setMatrixAt(i, it.m);
      im.setColorAt(i, it.c);
    });
    im.instanceMatrix.needsUpdate = true;
    return im;
  }

  dispose() {
    for (const ch of this.chunks.values()) this.disposeChunk(ch);
    this.chunks.clear();
    this.treeGeo.dispose();
    this.boxGeo.dispose();
  }
}
