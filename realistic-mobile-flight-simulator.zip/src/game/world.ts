import { fbm, ridged, hash, smoothstep, clamp } from './noise';

export const CHUNK = 1600;
export const SEA_LEVEL = 0;

let OX = 0;
let OZ = 0;

export type ZoneKind = 'airport' | 'town';
export interface Zone {
  id: string;
  kind: ZoneKind;
  x: number;
  z: number;
  elev: number;
  rFlat: number;
  rBlend: number;
  heading: number; // radians, 0 = north (-Z), pi/2 = east (+X)
  name: string;
  seed: number;
}

/** Terrain before flattening for towns / airports */
export function baseHeight(x: number, z: number): number {
  const nx = x + OX;
  const nz = z + OZ;
  const c = fbm(nx * 0.00006 + 3.1, nz * 0.00006 - 7.7, 3);
  const shore = smoothstep(-0.05, 0.05, c);
  const inland = Math.max(0, c);
  const hills = fbm(nx * 0.0004, nz * 0.0004, 4) * 110;
  const m = fbm(nx * 0.00005 + 100, nz * 0.00005 + 100, 2);
  const mMask = smoothstep(0.0, 0.26, m) * smoothstep(0.04, 0.22, c);
  const ridge = ridged(nx * 0.00019, nz * 0.00019, 5);
  const mount = Math.pow(ridge, 2.1) * 2900 * mMask;
  const detail = fbm(nx * 0.004, nz * 0.004, 3) * 9 * shore;
  const landH = 7 + inland * 170 + hills * shore + mount + detail;
  const seaH = -14 + c * 520;
  return seaH + (landH - seaH) * shore;
}

// ---------- zones ----------
const CELL_A = 10000;
const CELL_T = 4500;
const airportCache = new Map<string, Zone | null>();
const townCache = new Map<string, Zone | null>();

const LETTERS = 'ABCDEFGHIJKLMNOPRSTVW';
function airportName(i: number, j: number) {
  let s = 'K';
  for (let k = 0; k < 3; k++) s += LETTERS[Math.floor(hash(i, j, 50 + k) * LETTERS.length)];
  return s;
}

export function airportInCell(i: number, j: number): Zone | null {
  const key = i + ',' + j;
  if (airportCache.has(key)) return airportCache.get(key)!;
  let zone: Zone | null = null;
  if (i === 0 && j === 0) {
    zone = {
      id: 'home',
      kind: 'airport',
      x: 0,
      z: 0,
      elev: Math.max(baseHeight(0, 0), 25),
      rFlat: 1250,
      rBlend: 3000,
      heading: 0,
      name: 'HOME FIELD',
      seed: 1,
    };
  } else if (hash(i, j, 11) < 0.7) {
    const x = (i + 0.15 + 0.7 * hash(i, j, 12)) * CELL_A;
    const z = (j + 0.15 + 0.7 * hash(i, j, 13)) * CELL_A;
    if (Math.hypot(x, z) > 6000) {
      const b = baseHeight(x, z);
      if (b > 12 && b < 450) {
        zone = {
          id: 'a' + key,
          kind: 'airport',
          x,
          z,
          elev: b,
          rFlat: 1250,
          rBlend: 3000,
          heading: Math.floor(hash(i, j, 14) * 8) * (Math.PI / 4) + (hash(i, j, 15) - 0.5) * 0.2,
          name: airportName(i, j),
          seed: Math.floor(hash(i, j, 16) * 1000),
        };
      }
    }
  }
  airportCache.set(key, zone);
  return zone;
}

function nearAirport(x: number, z: number, r: number): boolean {
  const ci = Math.floor(x / CELL_A);
  const cj = Math.floor(z / CELL_A);
  for (let i = ci - 1; i <= ci + 1; i++)
    for (let j = cj - 1; j <= cj + 1; j++) {
      const a = airportInCell(i, j);
      if (a && Math.hypot(a.x - x, a.z - z) < r) return true;
    }
  return false;
}

export function townInCell(i: number, j: number): Zone | null {
  const key = i + ',' + j;
  if (townCache.has(key)) return townCache.get(key)!;
  let zone: Zone | null = null;
  if (hash(i, j, 21) < 0.5) {
    const x = (i + 0.25 + 0.5 * hash(i, j, 22)) * CELL_T;
    const z = (j + 0.25 + 0.5 * hash(i, j, 23)) * CELL_T;
    const b = baseHeight(x, z);
    if (b > 10 && b < 320 && !nearAirport(x, z, 4500)) {
      const rFlat = 380 + 380 * hash(i, j, 24);
      const e = 600;
      const flat =
        Math.abs(baseHeight(x + e, z) - b) < 45 &&
        Math.abs(baseHeight(x - e, z) - b) < 45 &&
        Math.abs(baseHeight(x, z + e) - b) < 45 &&
        Math.abs(baseHeight(x, z - e) - b) < 45;
      if (flat) {
        zone = {
          id: 't' + key,
          kind: 'town',
          x,
          z,
          elev: b,
          rFlat,
          rBlend: rFlat + 550,
          heading: 0,
          name: 'Town',
          seed: Math.floor(hash(i, j, 25) * 10000),
        };
      }
    }
  }
  townCache.set(key, zone);
  return zone;
}

/** all zones that may influence terrain within radius r of (x,z) */
export function zonesNear(x: number, z: number, r = 0): Zone[] {
  const out: Zone[] = [];
  const ci = Math.floor(x / CELL_A);
  const cj = Math.floor(z / CELL_A);
  for (let i = ci - 1; i <= ci + 1; i++)
    for (let j = cj - 1; j <= cj + 1; j++) {
      const a = airportInCell(i, j);
      if (a && Math.hypot(a.x - x, a.z - z) < a.rBlend + r) out.push(a);
    }
  const ti = Math.floor(x / CELL_T);
  const tj = Math.floor(z / CELL_T);
  const span = 1 + Math.ceil(r / CELL_T);
  for (let i = ti - span; i <= ti + span; i++)
    for (let j = tj - span; j <= tj + span; j++) {
      const t = townInCell(i, j);
      if (t && Math.hypot(t.x - x, t.z - z) < t.rBlend + r) out.push(t);
    }
  return out;
}

export function airportsNear(x: number, z: number, radius: number): Zone[] {
  const out: Zone[] = [];
  const n = Math.ceil(radius / CELL_A) + 1;
  const ci = Math.floor(x / CELL_A);
  const cj = Math.floor(z / CELL_A);
  for (let i = ci - n; i <= ci + n; i++)
    for (let j = cj - n; j <= cj + n; j++) {
      const a = airportInCell(i, j);
      if (a && Math.hypot(a.x - x, a.z - z) < radius) out.push(a);
    }
  return out;
}

export function getHeight(x: number, z: number, zones?: Zone[]): number {
  let h = baseHeight(x, z);
  const zs = zones ?? zonesNear(x, z);
  for (let k = 0; k < zs.length; k++) {
    const zn = zs[k];
    const d = Math.hypot(x - zn.x, z - zn.z);
    if (d < zn.rBlend) {
      const w = 1 - smoothstep(zn.rFlat, zn.rBlend, d);
      h += (zn.elev - h) * w;
    }
  }
  return h;
}

export function getNormal(x: number, z: number, out: { x: number; y: number; z: number }, e = 6) {
  const zs = zonesNear(x, z);
  const hx = getHeight(x + e, z, zs) - getHeight(x - e, z, zs);
  const hz = getHeight(x, z + e, zs) - getHeight(x, z - e, zs);
  const nx = -hx / (2 * e);
  const nz = -hz / (2 * e);
  const l = Math.sqrt(nx * nx + 1 + nz * nz);
  out.x = nx / l;
  out.y = 1 / l;
  out.z = nz / l;
}

export const RUNWAY_LEN = 1500;
export const RUNWAY_W = 42;

/** is the point on an airport runway / apron surface? */
export function onPavement(x: number, z: number): boolean {
  const zs = airportsNear(x, z, 1500);
  for (const a of zs) {
    const dx = x - a.x;
    const dz = z - a.z;
    // runway local coords: forward axis (sin h, -cos h)
    const s = Math.sin(a.heading);
    const c = Math.cos(a.heading);
    const along = dx * s - dz * c;
    const side = dx * c + dz * s;
    if (Math.abs(along) < RUNWAY_LEN / 2 + 20 && Math.abs(side) < RUNWAY_W / 2 + 6) return true;
    if (Math.abs(along) < 120 && side > 20 && side < 150) return true; // apron
  }
  return false;
}

/** Terrain forest density 0..1 */
export function forestMask(x: number, z: number, h: number): number {
  const f = smoothstep(0.0, 0.22, fbm((x + OX) / 1100 + 40, (z + OZ) / 1100, 3));
  return f * (1 - smoothstep(650, 1000, h)) * smoothstep(5, 14, h);
}

/** Search for a pleasant land spawn (continent interior) and set global noise offset */
export function initWorld() {
  OX = 0;
  OZ = 0;
  airportCache.clear();
  townCache.clear();
  const R = 2600;
  let best = { score: -1e9, x: 0, z: 0 };
  let a = 0;
  for (let k = 0; k < 260; k++) {
    a += 0.9;
    const r = 800 + k * 420;
    const px = Math.cos(a) * r;
    const pz = Math.sin(a) * r;
    // sample the area around the candidate
    let ok = true;
    let hSum = 0;
    let hMax = -1e9;
    let hMin = 1e9;
    for (let s = 0; s < 9; s++) {
      const ang = (s / 8) * Math.PI * 2;
      const rr = s === 8 ? 0 : R;
      const h = baseHeight(px + Math.cos(ang) * rr, pz + Math.sin(ang) * rr);
      hSum += h;
      hMax = Math.max(hMax, h);
      hMin = Math.min(hMin, h);
      if (h < 14) ok = false;
    }
    if (!ok || hMax > 260) continue;
    // want ocean / mountains reasonably close for scenery, but flat here
    const far1 = baseHeight(px + 12000, pz);
    const far2 = baseHeight(px - 12000, pz);
    const far3 = baseHeight(px, pz + 12000);
    const far4 = baseHeight(px, pz - 12000);
    const farMax = Math.max(far1, far2, far3, far4);
    const farMin = Math.min(far1, far2, far3, far4);
    const score = -(hMax - hMin) + (farMax > 500 ? 100 : 0) + (farMin < 0 ? 100 : 0) - (hSum / 9) * 0.1;
    if (score > best.score) best = { score, x: px, z: pz };
    if (score > 150) break;
  }
  OX = best.x;
  OZ = best.z;
  airportCache.clear();
  townCache.clear();
}

export function headingVec(h: number): [number, number] {
  return [Math.sin(h), -Math.cos(h)];
}

export function nearestAirport(x: number, z: number): Zone | null {
  const list = airportsNear(x, z, 45000);
  let best: Zone | null = null;
  let bd = 1e12;
  for (const a of list) {
    const d = Math.hypot(a.x - x, a.z - z);
    if (d < bd) {
      bd = d;
      best = a;
    }
  }
  return best;
}

export { clamp };
