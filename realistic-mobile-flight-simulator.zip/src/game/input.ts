// Shared mutable control state written by touch UI / keyboard, read by the game loop.
export const controls = {
  stickX: 0, // -1 (left) .. 1 (right)
  stickY: 0, // -1 (down) .. 1 (up) as dragged on screen
  rudder: 0, // -1..1
  throttle: 0,
  brake: false,
  keys: new Set<string>(),
};

export function resetControls() {
  controls.stickX = 0;
  controls.stickY = 0;
  controls.rudder = 0;
  controls.brake = false;
  controls.keys.clear();
}
