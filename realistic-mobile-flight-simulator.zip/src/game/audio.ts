export class EngineAudio {
  private ctx: AudioContext | null = null;
  private master!: GainNode;
  private osc1!: OscillatorNode;
  private osc2!: OscillatorNode;
  private engGain!: GainNode;
  private engFilter!: BiquadFilterNode;
  private noiseGain!: GainNode;
  private windGain!: GainNode;
  private windFilter!: BiquadFilterNode;
  private jet = false;
  muted = false;

  start(jet: boolean) {
    if (this.ctx) {
      this.ctx.resume?.();
      return;
    }
    this.jet = jet;
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      const ctx = new AC();
      this.ctx = ctx;
      this.master = ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.6;
      this.master.connect(ctx.destination);

      this.engFilter = ctx.createBiquadFilter();
      this.engFilter.type = 'lowpass';
      this.engFilter.frequency.value = 600;
      this.engGain = ctx.createGain();
      this.engGain.gain.value = 0;
      this.osc1 = ctx.createOscillator();
      this.osc1.type = 'sawtooth';
      this.osc2 = ctx.createOscillator();
      this.osc2.type = 'square';
      this.osc1.connect(this.engFilter);
      this.osc2.connect(this.engFilter);
      this.engFilter.connect(this.engGain);
      this.engGain.connect(this.master);
      this.osc1.start();
      this.osc2.start();

      // noise source
      const len = ctx.sampleRate * 2;
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      const mkNoise = () => {
        const s = ctx.createBufferSource();
        s.buffer = buf;
        s.loop = true;
        s.start();
        return s;
      };
      // jet roar / prop hiss
      const n1 = mkNoise();
      const nf = ctx.createBiquadFilter();
      nf.type = 'bandpass';
      nf.frequency.value = jet ? 900 : 1800;
      nf.Q.value = 0.6;
      this.noiseGain = ctx.createGain();
      this.noiseGain.gain.value = 0;
      n1.connect(nf);
      nf.connect(this.noiseGain);
      this.noiseGain.connect(this.master);
      // wind
      const n2 = mkNoise();
      this.windFilter = ctx.createBiquadFilter();
      this.windFilter.type = 'lowpass';
      this.windFilter.frequency.value = 500;
      this.windGain = ctx.createGain();
      this.windGain.gain.value = 0;
      n2.connect(this.windFilter);
      this.windFilter.connect(this.windGain);
      this.windGain.connect(this.master);
    } catch {
      this.ctx = null;
    }
  }

  resume() {
    this.ctx?.resume?.();
  }

  update(throttle: number, speed: number, paused: boolean) {
    const ctx = this.ctx;
    if (!ctx) return;
    const t = ctx.currentTime;
    const th = paused ? 0 : throttle;
    const sp = paused ? 0 : speed;
    if (this.jet) {
      this.osc1.frequency.setTargetAtTime(55 + th * 70, t, 0.1);
      this.osc2.frequency.setTargetAtTime(27 + th * 35, t, 0.1);
      this.engFilter.frequency.setTargetAtTime(250 + th * 500, t, 0.1);
      this.engGain.gain.setTargetAtTime(0.05 + th * 0.06, t, 0.1);
      this.noiseGain.gain.setTargetAtTime(0.03 + th * 0.35, t, 0.15);
    } else {
      const f = 38 + th * 52;
      this.osc1.frequency.setTargetAtTime(f, t, 0.08);
      this.osc2.frequency.setTargetAtTime(f * 0.5 + 0.7, t, 0.08);
      this.engFilter.frequency.setTargetAtTime(380 + th * 700, t, 0.1);
      this.engGain.gain.setTargetAtTime(0.1 + th * 0.12, t, 0.1);
      this.noiseGain.gain.setTargetAtTime(0.01 + th * 0.05, t, 0.15);
    }
    const w = Math.min(1, sp / (this.jet ? 250 : 80));
    this.windGain.gain.setTargetAtTime(w * 0.35, t, 0.2);
    this.windFilter.frequency.setTargetAtTime(300 + w * 1400, t, 0.2);
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.ctx) this.master.gain.setTargetAtTime(m ? 0 : 0.6, this.ctx.currentTime, 0.05);
  }

  /** short crash thud */
  crash() {
    const ctx = this.ctx;
    if (!ctx || this.muted) return;
    const len = ctx.sampleRate * 1.2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 3);
    const s = ctx.createBufferSource();
    s.buffer = buf;
    const f = ctx.createBiquadFilter();
    f.type = 'lowpass';
    f.frequency.value = 700;
    const g = ctx.createGain();
    g.gain.value = 1.2;
    s.connect(f);
    f.connect(g);
    g.connect(ctx.destination);
    s.start();
  }

  dispose() {
    try {
      this.ctx?.close();
    } catch {
      /* ignore */
    }
    this.ctx = null;
  }
}
