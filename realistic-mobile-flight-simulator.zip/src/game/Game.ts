import * as THREE from 'three';
import { SPECS, buildFalcon, buildSkyhawk, type AircraftId, type AircraftModel } from './aircraft';
import { Flight, type FlightControls } from './flight';
import { Terrain } from './terrain';
import { Clouds, PRESETS, Sky, Water, createAirport, disposeObject, type TimeOfDay } from './scenery';
import { EngineAudio } from './audio';
import { controls, resetControls } from './input';
import {
  CHUNK,
  RUNWAY_LEN,
  airportsNear,
  getHeight,
  headingVec,
  initWorld,
  nearestAirport,
  type Zone,
} from './world';
import { clamp } from './noise';

export type Quality = 'low' | 'medium' | 'high';

export interface GameSettings {
  aircraft: AircraftId;
  time: TimeOfDay;
  invertY: boolean;
  assist: boolean;
  quality: Quality;
  startInAir: boolean;
  sound: boolean;
}

export interface MapPoint {
  dx: number;
  dz: number;
  name: string;
}

export interface HudState {
  ready: boolean;
  loading: number;
  speedKt: number;
  altFt: number;
  aglFt: number;
  vsFpm: number;
  heading: number;
  pitch: number;
  roll: number;
  throttle: number;
  gear: number;
  gearDown: boolean;
  flaps: number;
  brake: boolean;
  onGround: boolean;
  stall: boolean;
  pullUp: boolean;
  gearWarn: boolean;
  crashed: string | null;
  fps: number;
  view: number;
  g: number;
  paused: boolean;
  nearest: { name: string; km: number; bearing: number } | null;
  map: MapPoint[];
  stallKt: number;
  vRotateKt: number;
  aircraftName: string;
}

const QUALITY: Record<Quality, { radius: number; dpr: number }> = {
  low: { radius: 3, dpr: 1 },
  medium: { radius: 4, dpr: 1.4 },
  high: { radius: 5, dpr: 2 },
};

const MS_TO_KT = 1.94384;
const M_TO_FT = 3.28084;

export class Game {
  settings: GameSettings;
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera: THREE.PerspectiveCamera;
  private terrain: Terrain;
  private sky: Sky;
  private water = new Water();
  private clouds: Clouds;
  private sun: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private model: AircraftModel;
  private shadow: THREE.Mesh;
  private flight: Flight;
  private audio = new EngineAudio();
  private airports = new Map<string, THREE.Group>();
  private explosion: { sprites: THREE.Sprite[]; vel: THREE.Vector3[]; t: number } | null = null;
  private explosionTex: THREE.CanvasTexture;

  private raf = 0;
  private last = performance.now();
  private time = 0;
  private fps = 60;
  private ready = false;
  private paused = false;
  private pendingSpawn: { x: number; y: number; z: number; heading: number; speed: number; air: boolean } | null = null;
  private loadProgress = 0;
  private gearDown = true;
  private flaps = 0;
  private view = 0;
  private camQuat = new THREE.Quaternion();
  private hudTimer = 0;
  private slowTimer = 0;
  private airportTimer = 0;
  private pullUp = false;
  private pullUpTimer = 0;
  private nearest: HudState['nearest'] = null;
  private map: MapPoint[] = [];
  private crashAnnounced = false;
  private fogFar = 5000;
  private disposed = false;
  private onHud: (h: HudState) => void;

  private _v = new THREE.Vector3();
  private _v2 = new THREE.Vector3();
  private _v3 = new THREE.Vector3();

  constructor(container: HTMLElement, settings: GameSettings, onHud: (h: HudState) => void) {
    this.container = container;
    this.settings = { ...settings };
    this.onHud = onHud;
    initWorld();

    const q = QUALITY[settings.quality];
    const dpr = Math.min(window.devicePixelRatio || 1, q.dpr);
    this.renderer = new THREE.WebGLRenderer({ antialias: dpr < 1.5, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.touchAction = 'none';
    container.appendChild(this.renderer.domElement);

    this.camera = new THREE.PerspectiveCamera(62, container.clientWidth / container.clientHeight, 1, 22000);

    const preset = PRESETS[settings.time];
    this.sky = new Sky(preset);
    this.scene.add(this.sky.mesh, this.sky.stars);
    this.scene.fog = new THREE.Fog(preset.horizon, 1000, 5000);
    this.hemi = new THREE.HemisphereLight(preset.hemiSky, preset.hemiGround, preset.hemiIntensity);
    this.sun = new THREE.DirectionalLight(preset.sunColor, preset.sunIntensity);
    this.sun.position.set(...preset.sunDir).multiplyScalar(1000);
    this.scene.add(this.hemi, this.sun, this.sun.target);

    this.terrain = new Terrain(this.scene, q.radius);
    this.terrain.setNight(preset.night);
    this.setFog(q.radius);
    this.scene.add(this.water.mesh);
    this.clouds = new Clouds(preset.cloud);
    this.scene.add(this.clouds.group);

    // aircraft
    const spec = SPECS[settings.aircraft];
    this.model = settings.aircraft === 'falcon' ? buildFalcon() : buildSkyhawk();
    this.scene.add(this.model.group);
    this.flight = new Flight(spec);

    const sg = new THREE.CircleGeometry(1, 20);
    sg.rotateX(-Math.PI / 2);
    this.shadow = new THREE.Mesh(
      sg,
      new THREE.MeshBasicMaterial({
        color: 0x000000,
        transparent: true,
        opacity: 0.35,
        depthWrite: false,
        polygonOffset: true,
        polygonOffsetFactor: -4,
        polygonOffsetUnits: -4,
      }),
    );
    this.shadow.renderOrder = 2;
    this.scene.add(this.shadow);

    // explosion texture
    const cv = document.createElement('canvas');
    cv.width = cv.height = 64;
    const g = cv.getContext('2d')!;
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.4, 'rgba(255,255,255,0.6)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    this.explosionTex = new THREE.CanvasTexture(cv);

    this.audio.muted = !settings.sound;

    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    document.addEventListener('visibilitychange', this.onVisibility);

    this.respawn(false);
    this.raf = requestAnimationFrame(this.loop);
  }

  // ------------------------------------------------------------ public API
  startAudio() {
    this.audio.start(this.settings.aircraft === 'falcon');
    this.audio.resume();
  }

  applySettings(s: Partial<GameSettings>) {
    Object.assign(this.settings, s);
    if (s.sound !== undefined) this.audio.setMuted(!s.sound);
  }

  setPaused(p: boolean) {
    this.paused = p;
    if (!p) this.last = performance.now();
    this.emitHud(true);
  }

  toggleGear() {
    if (this.flight.crashed) return;
    if (this.flight.onGround && this.gearDown && this.flight.speed > 3) return;
    this.gearDown = !this.gearDown;
  }

  cycleFlaps() {
    this.flaps = (this.flaps + 1) % 4;
  }

  cycleView() {
    this.view = (this.view + 1) % 3;
  }

  /** Reset to the runway of the nearest airport (or home on first spawn) */
  respawn(nearest: boolean) {
    let zone: Zone | null = null;
    if (nearest && this.ready) zone = nearestAirport(this.flight.pos.x, this.flight.pos.z);
    if (!zone) zone = airportsNear(0, 0, 100).find((a) => a.id === 'home') ?? null;
    if (!zone) return;
    const [dx, dz] = headingVec(zone.heading);
    const air = this.settings.startInAir && !nearest;
    const back = RUNWAY_LEN / 2 - 90;
    const spec = this.flight.spec;
    const speed = air ? (spec.jet ? 160 : 58) : 0;
    const px = air ? zone.x - dx * 400 : zone.x - dx * back;
    const pz = air ? zone.z - dz * 400 : zone.z - dz * back;
    const py = air ? zone.elev + 650 : zone.elev + 0.12 + spec.gearH;
    this.pendingSpawn = { x: px, y: py, z: pz, heading: zone.heading, speed, air };
    this.ready = false;
    this.crashAnnounced = false;
    this.clearExplosion();
    resetControls();
    if (air) {
      controls.throttle = spec.jet ? 0.75 : 0.65;
      this.gearDown = false;
    } else {
      controls.throttle = 0;
      this.gearDown = true;
    }
    this.flaps = 0;
    this.camQuat.setFromEuler(new THREE.Euler(0, -zone.heading, 0));
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    document.removeEventListener('visibilitychange', this.onVisibility);
    this.audio.dispose();
    this.terrain.dispose();
    this.airports.forEach((a) => disposeObject(a));
    disposeObject(this.model.group);
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }

  // ------------------------------------------------------------ internals
  private setFog(radius: number) {
    this.fogFar = radius * CHUNK * 0.94;
    const f = this.scene.fog as THREE.Fog;
    f.near = this.fogFar * 0.12;
    f.far = this.fogFar;
  }

  private onResize = () => {
    const w = this.container.clientWidth;
    const h = this.container.clientHeight;
    this.renderer.setSize(w, h);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  private onVisibility = () => {
    if (document.hidden && this.ready && !this.paused) {
      this.paused = true;
      this.emitHud(true);
    }
  };

  private onKeyDown = (e: KeyboardEvent) => {
    if (e.repeat) return;
    controls.keys.add(e.code);
    switch (e.code) {
      case 'KeyG':
        this.toggleGear();
        break;
      case 'KeyF':
        this.cycleFlaps();
        break;
      case 'KeyV':
      case 'KeyC':
        this.cycleView();
        break;
      case 'KeyR':
        this.respawn(e.shiftKey);
        break;
      case 'KeyP':
      case 'Escape':
        this.setPaused(!this.paused);
        break;
      case 'KeyM':
        this.applySettings({ sound: !this.settings.sound });
        break;
    }
    if (e.code.startsWith('Arrow') || e.code === 'Space' || e.code === 'Tab') e.preventDefault();
  };

  private onKeyUp = (e: KeyboardEvent) => {
    controls.keys.delete(e.code);
  };

  private curve(v: number) {
    return Math.sign(v) * Math.pow(Math.abs(v), 1.35);
  }

  private readControls(dt: number): FlightControls {
    const k = controls.keys;
    const has = (...c: string[]) => c.some((x) => k.has(x));
    const kPitchDown = has('ArrowUp', 'KeyW') ? 1 : 0; // push stick forward => nose down
    const kPitchUp = has('ArrowDown', 'KeyS') ? 1 : 0;
    let kp = kPitchUp - kPitchDown;
    if (this.settings.invertY) kp = -kp;
    const touch = this.curve(controls.stickY);
    let pitch = this.settings.invertY ? touch : -touch;
    pitch = clamp(pitch + (this.settings.invertY ? -kp : kp), -1, 1);
    const roll = clamp(
      this.curve(controls.stickX) + ((has('ArrowRight', 'KeyD') ? 1 : 0) - (has('ArrowLeft', 'KeyA') ? 1 : 0)),
      -1,
      1,
    );
    const yaw = clamp(
      controls.rudder + ((has('KeyE', 'Period') ? 1 : 0) - (has('KeyQ', 'Comma') ? 1 : 0)),
      -1,
      1,
    );
    if (has('ShiftLeft', 'ShiftRight', 'PageUp', 'KeyX')) controls.throttle += dt * 0.5;
    if (has('ControlLeft', 'ControlRight', 'PageDown', 'KeyZ')) controls.throttle -= dt * 0.5;
    controls.throttle = clamp(controls.throttle, 0, 1);
    return {
      pitch,
      roll,
      yaw,
      throttle: controls.throttle,
      brake: controls.brake || has('KeyB', 'Space'),
      gearDown: this.gearDown,
      flaps: this.flaps,
      assist: this.settings.assist,
    };
  }

  private loop = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.loop);
    const raw = (now - this.last) / 1000;
    this.last = now;
    const dt = Math.min(Math.max(raw, 0.001), 0.05);
    this.fps += (1 / Math.max(raw, 0.001) - this.fps) * 0.05;
    this.time += dt;
    const f = this.flight;

    if (!this.ready) {
      const sp = this.pendingSpawn!;
      this.terrain.update(sp.x, sp.z, 14);
      const total = 25;
      this.loadProgress = clamp(1 - this.terrain.nearPending / total, 0, 1);
      if (this.terrain.nearPending === 0) {
        f.reset(sp.x, sp.y, sp.z, sp.heading, sp.speed, !sp.air);
        f.gearPos = this.gearDown ? 1 : 0;
        f.flapsPos = 0;
        f.throttle = controls.throttle;
        this.ready = true;
        this.camQuat.copy(f.quat);
        this.applyEnvironment();
      }
      this.emitHud(false);
      this.sky.follow(this._v.set(sp.x, sp.y, sp.z));
      this.camera.position.set(sp.x, sp.y + 8, sp.z);
      this.camera.lookAt(sp.x, sp.y, sp.z - 100);
      this.renderer.render(this.scene, this.camera);
      return;
    }

    if (!this.paused) {
      const c = this.readControls(dt);
      const sub = 2;
      for (let i = 0; i < sub; i++) f.step(dt / sub, c);
      this.updateExplosion(dt);
      if (f.crashed && !this.crashAnnounced) {
        this.crashAnnounced = true;
        this.spawnExplosion();
        this.audio.crash();
      }
      this.terrain.update(f.pos.x, f.pos.z, 4);
    }

    this.updateVisuals(dt);
    this.updateCamera(dt);

    this.audio.update(f.throttle, f.speed, this.paused || !!f.crashed);

    this.airportTimer -= dt;
    if (this.airportTimer <= 0) {
      this.airportTimer = 1;
      this.manageAirports();
    }
    this.slowTimer -= dt;
    if (this.slowTimer <= 0) {
      this.slowTimer = 0.5;
      this.updateNav();
    }
    this.pullUpTimer -= dt;
    if (this.pullUpTimer <= 0) {
      this.pullUpTimer = 0.25;
      this.updatePullUp();
    }

    this.hudTimer -= dt;
    if (this.hudTimer <= 0) {
      this.hudTimer = 0.1;
      this.emitHud(false);
    }
    this.renderer.render(this.scene, this.camera);
  };

  private applyEnvironment() {
    const p = PRESETS[this.settings.time];
    this.terrain.setNight(p.night);
  }

  private updateVisuals(dt: number) {
    const f = this.flight;
    const m = this.model;
    m.group.position.copy(f.pos);
    m.group.quaternion.copy(f.quat);
    m.group.visible = this.view !== 1 && !f.crashed;
    if (m.prop) m.prop.rotation.z += (f.throttle * 70 + 6) * dt;
    if (m.propDisc) (m.propDisc.material as THREE.MeshBasicMaterial).opacity = Math.min(0.45, f.throttle * 0.55);
    if (m.prop) m.prop.visible = f.throttle < 0.55;
    if (m.flame) {
      m.flame.visible = f.throttle > 0.82;
      const s = 0.6 + (f.throttle - 0.8) * 4 + Math.sin(this.time * 60) * 0.12;
      m.flame.scale.set(1, Math.max(0.2, s), 1);
    }
    m.gear.visible = f.gearPos > 0.05;
    m.gear.scale.y = Math.max(0.05, f.gearPos);
    m.strobe.visible = Math.floor(this.time * 2.2) % 5 === 0;
    m.lights.forEach((l) => (l.visible = true));

    // sky / water / clouds follow
    this.sky.follow(this.camera.position);
    this.water.update(f.pos.x, f.pos.z, this.time, PRESETS[this.settings.time].night);
    this.clouds.update(f.pos.x, f.pos.z);

    // blob shadow
    const h = f.pos.y - f.surfaceY;
    const sp = f.spec;
    this.shadow.visible = h < 900 && !f.crashed;
    const k = 1 + Math.max(0, h) * 0.004;
    this.shadow.position.set(f.pos.x, f.surfaceY + 0.35, f.pos.z);
    const heading = Math.atan2(this._v.set(0, 0, -1).applyQuaternion(f.quat).x, -this._v.z);
    this.shadow.rotation.y = -heading;
    const span = 5.5;
    this.shadow.scale.set(span * k, 1, (sp.jet ? 8 : 4.5) * k);
    (this.shadow.material as THREE.MeshBasicMaterial).opacity = clamp(0.4 - h / 1800, 0.04, 0.4) * (f.overWater ? 0.4 : 1);
    this.sun.target.position.copy(f.pos);
    this.sun.position.copy(f.pos).addScaledVector(this._v2.set(...PRESETS[this.settings.time].sunDir).normalize(), 1000);
    this.sun.target.updateMatrixWorld();
  }

  private updateCamera(dt: number) {
    const f = this.flight;
    const sp = f.spec;
    const cam = this.camera;
    if (this.view === 1 && !f.crashed) {
      const off = this._v.set(...sp.cockpit).applyQuaternion(f.quat);
      cam.position.copy(f.pos).add(off);
      cam.quaternion.copy(f.quat);
      cam.up.set(0, 1, 0);
    } else {
      if (!f.crashed) this.camQuat.slerp(f.quat, 1 - Math.exp(-dt * 4.5));
      const far = this.view === 2 ? 2.4 : 1;
      const off = this._v.set(0, sp.camHeight * (this.view === 2 ? 1.4 : 1), sp.camDist * far).applyQuaternion(this.camQuat);
      cam.position.copy(f.pos).add(off);
      const gh = Math.max(getHeight(cam.position.x, cam.position.z), 0);
      if (cam.position.y < gh + 2.5) cam.position.y = gh + 2.5;
      const look = this._v2.set(0, 0, -30).applyQuaternion(this.camQuat).add(f.pos);
      look.y += 0.6 - sp.camHeight * (this.view === 2 ? 1.2 : 1.0);
      cam.up.set(0, 1, 0).lerp(this._v3.set(0, 1, 0).applyQuaternion(this.camQuat), 0.4).normalize();
      cam.lookAt(look);
    }
    const target = 62 + (sp.jet ? 14 : 8) * clamp(f.speed / (sp.jet ? 300 : 90), 0, 1);
    cam.fov += (target - cam.fov) * Math.min(1, dt * 2);
    cam.updateProjectionMatrix();
  }

  private manageAirports() {
    const f = this.flight;
    const near = airportsNear(f.pos.x, f.pos.z, 26000);
    const ids = new Set(near.map((a) => a.id));
    const night = PRESETS[this.settings.time].night;
    for (const a of near) {
      if (!this.airports.has(a.id)) {
        const g = createAirport(a, night);
        this.scene.add(g);
        this.airports.set(a.id, g);
      }
    }
    for (const [id, g] of this.airports) {
      if (!ids.has(id)) {
        this.scene.remove(g);
        disposeObject(g);
        this.airports.delete(id);
      }
    }
    for (const a of near) {
      const g = this.airports.get(a.id);
      const beam = g?.userData.beam as THREE.Mesh | undefined;
      if (beam) beam.visible = Math.hypot(a.x - f.pos.x, a.z - f.pos.z) > 1800;
    }
  }

  private updateNav() {
    const f = this.flight;
    const n = nearestAirport(f.pos.x, f.pos.z);
    if (n) {
      const dx = n.x - f.pos.x;
      const dz = n.z - f.pos.z;
      let b = (Math.atan2(dx, -dz) * 180) / Math.PI;
      b = (b + 360) % 360;
      this.nearest = { name: n.name, km: Math.hypot(dx, dz) / 1000, bearing: b };
    }
    this.map = airportsNear(f.pos.x, f.pos.z, 22000).map((a) => ({
      dx: a.x - f.pos.x,
      dz: a.z - f.pos.z,
      name: a.name,
    }));
  }

  private updatePullUp() {
    const f = this.flight;
    if (f.onGround || f.crashed || f.speed < 20) {
      this.pullUp = false;
      return;
    }
    let warn = false;
    for (const t of [2.5, 5, 8]) {
      const x = f.pos.x + f.vel.x * t;
      const z = f.pos.z + f.vel.z * t;
      const y = f.pos.y + f.vel.y * t;
      const h = Math.max(getHeight(x, z), 0);
      if (y - h < 35 && h > 25) warn = true;
    }
    this.pullUp = warn;
  }

  // ------------------------------------------------------------ explosion
  private spawnExplosion() {
    const sprites: THREE.Sprite[] = [];
    const vel: THREE.Vector3[] = [];
    const f = this.flight;
    for (let i = 0; i < 16; i++) {
      const mat = new THREE.SpriteMaterial({
        map: this.explosionTex,
        color: i < 8 ? 0xff9a30 : 0x222222,
        transparent: true,
        depthWrite: false,
        blending: i < 8 ? THREE.AdditiveBlending : THREE.NormalBlending,
        fog: false,
      });
      const s = new THREE.Sprite(mat);
      s.position.copy(f.pos).add(this._v.set(0, 2, 0));
      s.scale.setScalar(8);
      this.scene.add(s);
      sprites.push(s);
      vel.push(new THREE.Vector3((Math.random() - 0.5) * 22, Math.random() * 14 + 2, (Math.random() - 0.5) * 22));
    }
    this.explosion = { sprites, vel, t: 0 };
  }

  private updateExplosion(dt: number) {
    const e = this.explosion;
    if (!e) return;
    e.t += dt;
    e.sprites.forEach((s, i) => {
      s.position.addScaledVector(e.vel[i], dt);
      e.vel[i].multiplyScalar(1 - dt * 0.8);
      const k = i < 8 ? 1 : 0.7;
      s.scale.setScalar(8 + e.t * (i < 8 ? 18 : 12));
      (s.material as THREE.SpriteMaterial).opacity = clamp(1 - e.t / (i < 8 ? 1.8 : 5), 0, 1) * k;
    });
  }

  private clearExplosion() {
    if (!this.explosion) return;
    this.explosion.sprites.forEach((s) => {
      this.scene.remove(s);
      (s.material as THREE.Material).dispose();
    });
    this.explosion = null;
  }

  // ------------------------------------------------------------ HUD
  private emitHud(force: boolean) {
    void force;
    const f = this.flight;
    const sp = f.spec;
    const fwd = this._v.set(0, 0, -1).applyQuaternion(f.quat);
    const right = this._v2.set(1, 0, 0).applyQuaternion(f.quat);
    const up = this._v3.set(0, 1, 0).applyQuaternion(f.quat);
    const heading = (((Math.atan2(fwd.x, -fwd.z) * 180) / Math.PI) + 360) % 360;
    const pitch = (Math.asin(clamp(fwd.y, -1, 1)) * 180) / Math.PI;
    const roll = (Math.atan2(-right.y, up.y) * 180) / Math.PI;
    const gearWarn =
      this.ready &&
      !f.onGround &&
      !this.gearDown &&
      !f.crashed &&
      f.agl < (sp.jet ? 250 : 150) &&
      f.speed * MS_TO_KT < (sp.jet ? 260 : 100) &&
      f.throttle < 0.6;
    this.onHud({
      ready: this.ready,
      loading: this.loadProgress,
      speedKt: f.speed * MS_TO_KT,
      altFt: f.pos.y * M_TO_FT,
      aglFt: Math.max(0, f.agl) * M_TO_FT,
      vsFpm: f.vel.y * 196.85,
      heading,
      pitch,
      roll,
      throttle: controls.throttle,
      gear: f.gearPos,
      gearDown: this.gearDown,
      flaps: this.flaps,
      brake: controls.brake,
      onGround: f.onGround,
      stall: f.stall && !f.crashed,
      pullUp: this.pullUp,
      gearWarn,
      crashed: f.crashed,
      fps: Math.round(this.fps),
      view: this.view,
      g: f.gLoad,
      paused: this.paused,
      nearest: this.nearest,
      map: this.map,
      stallKt: sp.stallKt,
      vRotateKt: sp.vRotate * MS_TO_KT,
      aircraftName: sp.name,
    });
  }
}
