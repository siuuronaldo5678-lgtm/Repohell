import * as THREE from 'three';
import { RUNWAY_LEN, RUNWAY_W, type Zone } from './world';
import { mulberry32 } from './noise';

export type TimeOfDay = 'day' | 'sunset' | 'night';

export interface TimePreset {
  top: number;
  horizon: number;
  sunDir: [number, number, number];
  sunColor: number;
  sunIntensity: number;
  hemiSky: number;
  hemiGround: number;
  hemiIntensity: number;
  stars: number;
  night: number;
  cloud: number;
}

export const PRESETS: Record<TimeOfDay, TimePreset> = {
  day: {
    top: 0x2a68b8,
    horizon: 0xbcd6ee,
    sunDir: [0.45, 0.72, -0.5],
    sunColor: 0xfff2dc,
    sunIntensity: 2.6,
    hemiSky: 0xbcd4f2,
    hemiGround: 0x726a55,
    hemiIntensity: 1.5,
    stars: 0,
    night: 0,
    cloud: 0xffffff,
  },
  sunset: {
    top: 0x23356e,
    horizon: 0xf2a37a,
    sunDir: [0.85, 0.1, -0.35],
    sunColor: 0xffa766,
    sunIntensity: 2.2,
    hemiSky: 0x9a82a8,
    hemiGround: 0x4a382e,
    hemiIntensity: 1.0,
    stars: 0.1,
    night: 0.15,
    cloud: 0xffc9a0,
  },
  night: {
    top: 0x010309,
    horizon: 0x16213f,
    sunDir: [-0.3, 0.55, 0.45],
    sunColor: 0x8da6ff,
    sunIntensity: 1.1,
    hemiSky: 0x4a5f9a,
    hemiGround: 0x232a3c,
    hemiIntensity: 1.25,
    stars: 1,
    night: 1,
    cloud: 0x3a4468,
  },
};

// ------------------------------------------------------------------ sky
export class Sky {
  mesh: THREE.Mesh;
  stars: THREE.Points;
  uniforms: Record<string, { value: unknown }>;

  constructor(p: TimePreset) {
    this.uniforms = {
      top: { value: new THREE.Color(p.top) },
      horizon: { value: new THREE.Color(p.horizon) },
      sunDir: { value: new THREE.Vector3(...p.sunDir).normalize() },
      sunColor: { value: new THREE.Color(p.sunColor) },
    };
    const mat = new THREE.ShaderMaterial({
      uniforms: this.uniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      vertexShader: `
        varying vec3 vDir;
        void main(){
          vDir = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
        }`,
      fragmentShader: `
        uniform vec3 top; uniform vec3 horizon; uniform vec3 sunDir; uniform vec3 sunColor;
        varying vec3 vDir;
        void main(){
          vec3 d = normalize(vDir);
          float h = clamp(d.y, -0.2, 1.0);
          float t = pow(max(h,0.0), 0.55);
          vec3 col = mix(horizon, top, t);
          col = mix(col, horizon * 0.85, smoothstep(0.0, -0.2, d.y));
          float s = max(dot(d, normalize(sunDir)), 0.0);
          col += sunColor * pow(s, 8.0) * 0.28;
          col += sunColor * pow(s, 80.0) * 0.5;
          col += sunColor * smoothstep(0.9993, 0.9998, s) * 2.0;
          gl_FragColor = vec4(col, 1.0);
          #include <colorspace_fragment>
        }`,
    });
    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(16000, 32, 16), mat);
    this.mesh.renderOrder = -10;
    this.mesh.frustumCulled = false;

    // stars
    const rnd = mulberry32(99);
    const N = 900;
    const arr = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) {
      const u = rnd() * 2 - 1;
      const a = rnd() * Math.PI * 2;
      const r = Math.sqrt(1 - u * u);
      arr[i * 3] = Math.cos(a) * r * 15000;
      arr[i * 3 + 1] = Math.abs(u) * 15000 * 0.98 + 200;
      arr[i * 3 + 2] = Math.sin(a) * r * 15000;
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(arr, 3));
    this.stars = new THREE.Points(
      g,
      new THREE.PointsMaterial({
        color: 0xffffff,
        size: 2,
        sizeAttenuation: false,
        transparent: true,
        opacity: p.stars,
        fog: false,
        depthWrite: false,
      }),
    );
    this.stars.frustumCulled = false;
    this.stars.renderOrder = -9;
  }

  follow(pos: THREE.Vector3) {
    this.mesh.position.copy(pos);
    this.stars.position.copy(pos);
  }
}

// ------------------------------------------------------------------ water
export class Water {
  mesh: THREE.Mesh;
  tex: THREE.CanvasTexture;
  static TILE = 300;

  constructor() {
    const s = 256;
    const cv = document.createElement('canvas');
    cv.width = cv.height = s;
    const g = cv.getContext('2d')!;
    g.fillStyle = '#808080';
    g.fillRect(0, 0, s, s);
    // tileable wave blobs
    const rnd = mulberry32(5);
    for (let i = 0; i < 700; i++) {
      const x = rnd() * s;
      const y = rnd() * s;
      const r = 3 + rnd() * 14;
      const v = rnd() > 0.5 ? 255 : 0;
      for (const ox of [-s, 0, s])
        for (const oy of [-s, 0, s]) {
          const gr = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, r);
          gr.addColorStop(0, `rgba(${v},${v},${v},0.25)`);
          gr.addColorStop(1, `rgba(${v},${v},${v},0)`);
          g.fillStyle = gr;
          g.fillRect(x + ox - r, y + oy - r, r * 2, r * 2);
        }
    }
    this.tex = new THREE.CanvasTexture(cv);
    this.tex.wrapS = this.tex.wrapT = THREE.RepeatWrapping;
    const size = 60000;
    this.tex.repeat.set(size / Water.TILE, size / Water.TILE);
    const mat = new THREE.MeshPhongMaterial({
      color: 0x1d5f8c,
      specular: 0xffffff,
      shininess: 90,
      transparent: true,
      opacity: 0.86,
      bumpMap: this.tex,
      bumpScale: 2.2,
    });
    const geo = new THREE.PlaneGeometry(size, size, 1, 1);
    geo.rotateX(-Math.PI / 2);
    this.mesh = new THREE.Mesh(geo, mat);
    this.mesh.position.y = 0;
    this.mesh.renderOrder = 1;
  }

  update(px: number, pz: number, t: number, night: number) {
    const T = Water.TILE;
    this.mesh.position.x = Math.round(px / T) * T;
    this.mesh.position.z = Math.round(pz / T) * T;
    this.tex.offset.x = (t * 0.004) % 1;
    this.tex.offset.y = (t * 0.0025) % 1;
    const m = this.mesh.material as THREE.MeshPhongMaterial;
    m.color.setHex(0x1d5f8c).multiplyScalar(1 - night * 0.8);
  }
}

// ------------------------------------------------------------------ clouds
export class Clouds {
  group = new THREE.Group();
  clusters: THREE.Group[] = [];
  mats: THREE.SpriteMaterial[] = [];
  static SPAN = 28000;

  constructor(color: number) {
    const s = 128;
    const cv = document.createElement('canvas');
    cv.width = cv.height = s;
    const g = cv.getContext('2d')!;
    const gr = g.createRadialGradient(s / 2, s / 2, 0, s / 2, s / 2, s / 2);
    gr.addColorStop(0, 'rgba(255,255,255,0.95)');
    gr.addColorStop(0.45, 'rgba(255,255,255,0.55)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, s, s);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    const rnd = mulberry32(2024);
    const mat = new THREE.SpriteMaterial({ map: tex, color, transparent: true, depthWrite: false, opacity: 0.85 });
    this.mats.push(mat);
    const N = 70;
    for (let i = 0; i < N; i++) {
      const cl = new THREE.Group();
      const baseY = 2300 + rnd() * 900;
      const cx = (rnd() - 0.5) * Clouds.SPAN;
      const cz = (rnd() - 0.5) * Clouds.SPAN;
      const size = 500 + rnd() * 900;
      const puffs = 6 + Math.floor(rnd() * 8);
      for (let k = 0; k < puffs; k++) {
        const sp = new THREE.Sprite(mat);
        const sc = size * (0.5 + rnd() * 0.8);
        sp.scale.set(sc, sc * (0.45 + rnd() * 0.25), 1);
        sp.position.set((rnd() - 0.5) * size * 1.8, (rnd() - 0.4) * size * 0.3, (rnd() - 0.5) * size * 1.2);
        cl.add(sp);
      }
      cl.position.set(cx, baseY, cz);
      this.group.add(cl);
      this.clusters.push(cl);
    }
  }

  update(px: number, pz: number) {
    const S = Clouds.SPAN;
    for (const c of this.clusters) {
      c.position.x += S * Math.round((px - c.position.x) / S);
      c.position.z += S * Math.round((pz - c.position.z) / S);
    }
  }

  setColor(c: number) {
    this.mats.forEach((m) => m.color.setHex(c));
  }
}

// ------------------------------------------------------------------ airport
function runwayTexture(): THREE.CanvasTexture {
  const w = 128;
  const h = 2048;
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const g = cv.getContext('2d')!;
  g.fillStyle = '#3b3d40';
  g.fillRect(0, 0, w, h);
  // asphalt speckle
  for (let i = 0; i < 6000; i++) {
    const v = 50 + Math.random() * 30;
    g.fillStyle = `rgba(${v},${v},${v + 3},0.5)`;
    g.fillRect(Math.random() * w, Math.random() * h, 2, 2);
  }
  // rubber marks near thresholds
  g.fillStyle = 'rgba(15,15,15,0.35)';
  g.fillRect(w * 0.35, h * 0.1, 8, h * 0.07);
  g.fillRect(w * 0.55, h * 0.1, 8, h * 0.07);
  g.fillRect(w * 0.35, h * 0.83, 8, h * 0.07);
  g.fillRect(w * 0.55, h * 0.83, 8, h * 0.07);
  g.fillStyle = '#e9e9e4';
  // centerline dashes
  for (let y = h * 0.1; y < h * 0.9; y += 56) g.fillRect(w / 2 - 2, y, 4, 30);
  // edge lines
  g.fillRect(4, 0, 3, h);
  g.fillRect(w - 7, 0, 3, h);
  // piano keys at both ends
  for (const y0 of [h * 0.015, h * 0.985 - 70]) {
    for (let k = 0; k < 8; k++) {
      g.fillRect(12 + k * 13, y0, 7, 70);
    }
  }
  // threshold bars
  g.fillRect(10, h * 0.045, w - 20, 5);
  g.fillRect(10, h * 0.955, w - 20, 5);
  // aiming-point blocks
  for (const y0 of [h * 0.17, h * 0.83 - 40]) {
    g.fillRect(22, y0, 18, 40);
    g.fillRect(w - 40, y0, 18, 40);
  }
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

let sharedRunwayTex: THREE.CanvasTexture | null = null;

export function createAirport(a: Zone, night: number): THREE.Group {
  const g = new THREE.Group();
  g.position.set(a.x, a.elev, a.z);
  g.rotation.y = -a.heading;
  if (!sharedRunwayTex) sharedRunwayTex = runwayTexture();

  const rwMat = new THREE.MeshLambertMaterial({ map: sharedRunwayTex, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const rw = new THREE.Mesh(new THREE.PlaneGeometry(RUNWAY_W, RUNWAY_LEN), rwMat);
  rw.rotation.x = -Math.PI / 2;
  rw.position.y = 0.12;
  g.add(rw);

  const asphalt = new THREE.MeshLambertMaterial({ color: 0x4a4c50, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -1 });
  const apron = new THREE.Mesh(new THREE.PlaneGeometry(130, 240), asphalt);
  apron.rotation.x = -Math.PI / 2;
  apron.position.set(RUNWAY_W / 2 + 90, 0.1, 0);
  g.add(apron);
  const taxi = new THREE.Mesh(new THREE.PlaneGeometry(RUNWAY_W / 2 + 90, 18), asphalt);
  taxi.rotation.x = -Math.PI / 2;
  taxi.position.set(RUNWAY_W / 4 + 45, 0.11, 100);
  g.add(taxi);
  const taxi2 = taxi.clone();
  taxi2.position.z = -100;
  g.add(taxi2);

  // buildings
  const white = new THREE.MeshLambertMaterial({ color: 0xe8e6df });
  const roofMat = new THREE.MeshLambertMaterial({ color: 0x8a95a3 });
  const glass = new THREE.MeshLambertMaterial({ color: 0x2a4a5f, emissive: 0xffd080, emissiveIntensity: night * 0.8 });
  for (let i = 0; i < 3; i++) {
    const hg = new THREE.Group();
    const body = new THREE.Mesh(new THREE.BoxGeometry(34, 9, 30), white);
    body.position.y = 4.5;
    const roof = new THREE.Mesh(
      new THREE.CylinderGeometry(17, 17, 30, 14, 1, false, Math.PI / 2, Math.PI),
      roofMat,
    );
    roof.rotation.set(Math.PI / 2, 0, 0);
    roof.scale.set(1, 1, 0.38);
    roof.position.y = 9;
    hg.add(body, roof);
    hg.position.set(RUNWAY_W / 2 + 130, 0, -80 + i * 55);
    hg.rotation.y = 0;
    g.add(hg);
  }
  // tower
  const tw = new THREE.Group();
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 3, 26, 8), white);
  shaft.position.y = 13;
  const cab = new THREE.Mesh(new THREE.CylinderGeometry(5.5, 4, 5, 8), glass);
  cab.position.y = 28.5;
  const capm = new THREE.Mesh(new THREE.CylinderGeometry(6, 6, 0.8, 8), roofMat);
  capm.position.y = 31.4;
  tw.add(shaft, cab, capm);
  tw.position.set(RUNWAY_W / 2 + 60, 0, 95);
  g.add(tw);
  // terminal
  const term = new THREE.Mesh(new THREE.BoxGeometry(60, 10, 22), white);
  term.position.set(RUNWAY_W / 2 + 90, 5, 60);
  const tg = new THREE.Mesh(new THREE.BoxGeometry(58, 4, 22.5), glass);
  tg.position.set(RUNWAY_W / 2 + 90, 4, 60);
  g.add(term, tg);

  // runway edge lights
  const lightGeo = new THREE.BoxGeometry(0.8, 0.5, 0.8);
  const lightMat = new THREE.MeshBasicMaterial({ color: 0xfff1c0, fog: false });
  const nL = Math.floor(RUNWAY_LEN / 40) + 1;
  const lights = new THREE.InstancedMesh(lightGeo, lightMat, nL * 2);
  const m = new THREE.Matrix4();
  for (let i = 0; i < nL; i++) {
    const z = -RUNWAY_LEN / 2 + i * 40;
    m.setPosition(-RUNWAY_W / 2 - 1.5, 0.3, z);
    lights.setMatrixAt(i * 2, m);
    m.setPosition(RUNWAY_W / 2 + 1.5, 0.3, z);
    lights.setMatrixAt(i * 2 + 1, m);
  }
  g.add(lights);
  // threshold lights green / red
  const gMat = new THREE.MeshBasicMaterial({ color: 0x20ff60 });
  const rMat = new THREE.MeshBasicMaterial({ color: 0xff3020 });
  for (let k = -3; k <= 3; k++) {
    const a1 = new THREE.Mesh(lightGeo, gMat);
    a1.position.set(k * 5.5, 0.3, -RUNWAY_LEN / 2 - 2);
    const a2 = new THREE.Mesh(lightGeo, rMat);
    a2.position.set(k * 5.5, 0.3, RUNWAY_LEN / 2 + 2);
    g.add(a1, a2);
  }
  // approach strobes
  const sMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  for (let i = 1; i <= 8; i++) {
    for (const sgn of [-1, 1]) {
      const s1 = new THREE.Mesh(lightGeo, sMat);
      s1.position.set(0, 0.5, sgn * (RUNWAY_LEN / 2 + i * 30));
      g.add(s1);
    }
  }

  // beacon beam (visible from far away)
  const beam = new THREE.Mesh(
    new THREE.CylinderGeometry(10, 10, 4000, 10, 1, true),
    new THREE.MeshBasicMaterial({
      color: 0x55d6ff,
      transparent: true,
      opacity: 0.16,
      depthWrite: false,
      fog: false,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
    }),
  );
  beam.position.set(RUNWAY_W / 2 + 90, 2000, 0);
  g.add(beam);
  g.userData.beam = beam;
  return g;
}

export function disposeObject(o: THREE.Object3D) {
  o.traverse((c) => {
    const m = c as THREE.Mesh;
    if (m.geometry) m.geometry.dispose();
    const mat = m.material as THREE.Material | THREE.Material[] | undefined;
    if (mat) (Array.isArray(mat) ? mat : [mat]).forEach((x) => x.dispose());
  });
}
