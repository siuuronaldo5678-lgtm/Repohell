import * as THREE from 'three';
import type { AircraftSpec } from './aircraft';
import { getHeight, getNormal, onPavement, zonesNear } from './world';
import { clamp } from './noise';

export interface FlightControls {
  pitch: number; // + = nose up
  roll: number; // + = roll right
  yaw: number; // + = rudder right
  throttle: number;
  brake: boolean;
  gearDown: boolean;
  flaps: number; // 0..3
  assist: boolean;
}

const G = 9.81;
const _qInv = new THREE.Quaternion();
const _vl = new THREE.Vector3();
const _vhat = new THREE.Vector3();
const _right = new THREE.Vector3();
const _up = new THREE.Vector3();
const _fwd = new THREE.Vector3();
const _lift = new THREE.Vector3();
const _acc = new THREE.Vector3();
const _tmp = new THREE.Vector3();
const _dq = new THREE.Quaternion();
const _e = new THREE.Euler();
const _n = { x: 0, y: 1, z: 0 };

export class Flight {
  spec: AircraftSpec;
  pos = new THREE.Vector3();
  vel = new THREE.Vector3();
  quat = new THREE.Quaternion();
  rateP = 0; // pitch rate (about body x)
  rateY = 0; // yaw rate (about body y)
  rateR = 0; // roll rate (about body z)
  throttle = 0;
  gearPos = 1;
  flapsPos = 0;
  onGround = true;
  crashed: string | null = null;
  stall = false;
  alpha = 0;
  speed = 0;
  gLoad = 1;
  surfaceY = 0;
  agl = 0;
  overWater = false;
  private holdG = 0;
  private holdTimer = 0;
  private trimInt = 0;
  private time = 0;

  constructor(spec: AircraftSpec) {
    this.spec = spec;
  }

  reset(x: number, y: number, z: number, heading: number, speed: number, onGround: boolean) {
    this.pos.set(x, y, z);
    this.quat.setFromEuler(_e.set(0, -heading, 0, 'YXZ'));
    this.vel.set(Math.sin(heading) * speed, 0, -Math.cos(heading) * speed);
    this.rateP = this.rateR = this.rateY = 0;
    this.onGround = onGround;
    this.crashed = null;
    this.stall = false;
    this.holdG = 0;
    this.trimInt = 0;
    this.holdTimer = 0;
    this.gLoad = 1;
  }

  get wheelH() {
    return this.gearPos > 0.7 ? this.spec.gearH : this.spec.bellyH;
  }

  forward(out: THREE.Vector3) {
    return out.set(0, 0, -1).applyQuaternion(this.quat);
  }

  step(dt: number, c: FlightControls) {
    if (this.crashed) return;
    const sp = this.spec;
    this.time += dt;

    // engine / gear / flaps actuators
    this.throttle += clamp(c.throttle - this.throttle, -dt * 0.9, dt * 0.9);
    this.gearPos += clamp((c.gearDown ? 1 : 0) - this.gearPos, -dt * 0.4, dt * 0.4);
    this.flapsPos += clamp(c.flaps / 3 - this.flapsPos, -dt * 0.4, dt * 0.4);

    // body axes
    _right.set(1, 0, 0).applyQuaternion(this.quat);
    _up.set(0, 1, 0).applyQuaternion(this.quat);
    _fwd.set(0, 0, -1).applyQuaternion(this.quat);
    _qInv.copy(this.quat).invert();
    _vl.copy(this.vel).applyQuaternion(_qInv);
    const V = this.vel.length();
    this.speed = V;
    const rho = 1.225 * Math.exp(-Math.max(0, this.pos.y) / 9000);
    const dyn = 0.5 * rho * V * V;
    const alpha = V > 1 ? Math.atan2(-_vl.y, -_vl.z) : 0;
    const beta = V > 1 ? Math.asin(clamp(_vl.x / V, -1, 1)) : 0;
    this.alpha = alpha;
    const aS = sp.stallAlpha - this.flapsPos * 0.025;
    this.stall = !this.onGround && (alpha > aS * 0.92 || (V < sp.stallKt * 0.5144 * 0.8 && this.agl > 3));

    // ------------------------------------------------ control laws
    let pIn = c.pitch;
    let rIn = c.roll;
    const yIn = c.yaw;
    const bank = Math.atan2(-_right.y, _up.y);
    const flying = !this.onGround && V > sp.stallKt * 0.5144 * 1.05;
    if (c.assist && flying) {
      const gamma = Math.asin(clamp(this.vel.y / Math.max(V, 1), -1, 1));
      if (Math.abs(pIn) > 0.04) {
        this.holdG = gamma;
        this.holdTimer = 0.35;
      } else if (this.holdTimer > 0) {
        this.holdTimer -= dt;
        this.holdG = gamma;
      } else {
        const err = this.holdG - gamma;
        const gs = clamp((1.4 * sp.vRef) / Math.max(V, 1), 0.3, 2);
        this.trimInt = clamp(this.trimInt + err * dt * 0.3 * gs, -0.5, 0.5);
        pIn = clamp(err * 1.2 * gs + this.trimInt, -0.6, 0.6);
      }
      // bank limit + auto-level
      if (Math.abs(rIn) < 0.05) {
        rIn = clamp(-bank * 1.4, -0.7, 0.7);
      } else if ((bank > 1.05 && rIn > 0) || (bank < -1.05 && rIn < 0)) {
        rIn = 0;
      }
    } else if (!c.assist) {
      this.trimInt = 0;
    }

    // ------------------------------------------------ rotation dynamics
    const e = clamp(V / sp.vRef, 0.1, 1.3);
    const ePitch = V > sp.vRef ? Math.max(0.35, sp.vRef / V) * 1.1 : e;
    const stab = clamp(V / sp.vRef, 0, 1.2);
    let qT = pIn * sp.pitchRate * ePitch - (alpha - sp.alphaTrim) * 2.0 * stab;
    // structural G limiter
    const gLim = sp.jet ? 8.5 : 4.5;
    if (dyn > 50) {
      const clAllow = (gLim * G * sp.wl) / dyn;
      const aCap = clamp((clAllow - sp.cl0) / sp.clAlpha, 0.03, 1.2);
      const aCapN = clamp((0.45 * clAllow + sp.cl0) / sp.clAlpha, 0.03, 1.2);
      if (alpha > aCap) qT = Math.min(qT, -(alpha - aCap) * 6);
      if (alpha < -aCapN) qT = Math.max(qT, (-aCapN - alpha) * 6);
    }
    // alpha limiter in assist mode
    if (c.assist && flying && qT > 0) qT *= clamp((aS * 0.9 - alpha) / 0.06, 0, 1);

    const rT = -rIn * sp.rollRate * e;
    const yT = -yIn * sp.yawRate * e - beta * 2.0 * stab;
    this.rateP += (qT - this.rateP) * (1 - Math.exp(-dt * 6));
    this.rateR += (rT - this.rateR) * (1 - Math.exp(-dt * 7));
    this.rateY += (yT - this.rateY) * (1 - Math.exp(-dt * 4));
    if (!this.onGround) {
      _tmp.set(this.rateP, this.rateY, this.rateR);
      const ang = _tmp.length() * dt;
      if (ang > 1e-6) {
        _dq.setFromAxisAngle(_tmp.normalize(), ang);
        this.quat.multiply(_dq).normalize();
      }
    }

    // ------------------------------------------------ forces
    const flapCL = this.flapsPos * 0.5;
    const clPeak = sp.cl0 + flapCL + sp.clAlpha * aS;
    let cl: number;
    if (alpha > aS) cl = clPeak * Math.max(0.25, 1 - (alpha - aS) * 2.2);
    else if (alpha < -aS) cl = sp.cl0 - sp.clAlpha * aS * 0.9 + (-aS - alpha) * 1.5;
    else cl = sp.cl0 + flapCL + sp.clAlpha * alpha;
    if (alpha > 1.55 || alpha < -1.55) cl = 0;
    cl = clamp(cl, -1.4, 2.4);
    let cd =
      sp.cd0 +
      this.flapsPos * 0.03 +
      this.gearPos * (sp.jet ? 0.014 : 0.012) +
      sp.k * cl * cl +
      Math.max(0, Math.abs(alpha) - aS) * 1.4;
    if (c.brake && !this.onGround) cd += sp.jet ? 0.05 : 0.02; // air brake / spoilers
    this.gLoad = V > 1 ? (dyn * cl) / sp.wl / G : 1;

    _acc.set(0, -G, 0);
    if (V > 0.5) {
      _vhat.copy(this.vel).divideScalar(V);
      _lift.copy(_right).cross(_vhat);
      if (_lift.lengthSq() > 1e-6) {
        _lift.normalize();
        _acc.addScaledVector(_lift, (dyn * cl) / sp.wl);
      }
      _acc.addScaledVector(_vhat, -(dyn * cd) / sp.wl);
      _acc.addScaledVector(_right, -(dyn * beta * 1.1) / sp.wl);
    }
    const dens = Math.pow(rho / 1.225, 0.8);
    let T: number;
    if (sp.jet) T = sp.thrust * this.throttle * (0.3 + 0.7 * dens);
    else T = sp.thrust * this.throttle * Math.max(0, 1 - V / sp.vTh) * dens;
    _acc.addScaledVector(_fwd, T);

    // gentle turbulence (stronger in low, rough air)
    const lowAir = clamp(1 - (this.agl - 20) / 1500, 0.35, 1);
    const turb = this.onGround ? 0 : 0.35 * lowAir;
    const t = this.time;
    _acc.x += (Math.sin(t * 1.3) + Math.sin(t * 2.9 + 1)) * turb;
    _acc.y += (Math.sin(t * 1.7 + 2) + Math.sin(t * 3.7)) * turb;
    _acc.z += (Math.sin(t * 1.1 + 4) + Math.sin(t * 2.3)) * turb * 0.5;

    this.vel.addScaledVector(_acc, dt);
    this.pos.addScaledVector(this.vel, dt);

    // ------------------------------------------------ terrain contact
    const zs = zonesNear(this.pos.x, this.pos.z);
    const gh = getHeight(this.pos.x, this.pos.z, zs);
    this.overWater = gh < 0;
    this.surfaceY = Math.max(gh, 0);
    const wh = this.wheelH;
    this.agl = this.pos.y - this.surfaceY - wh;
    if (this.agl <= 0) {
      if (this.overWater) {
        this.crashed = 'You crashed into the sea.';
        this.vel.set(0, 0, 0);
        return;
      }
      getNormal(this.pos.x, this.pos.z, _n);
      const vn = -(this.vel.x * _n.x + this.vel.y * _n.y + this.vel.z * _n.z);
      const eul = _e.setFromQuaternion(this.quat, 'YXZ');
      const wasAir = !this.onGround;
      let reason: string | null = null;
      if (vn > sp.maxSink) reason = 'Impact was too hard — descent rate too high.';
      else if (this.gearPos < 0.7 && V > 22) reason = 'Landed with the gear up.';
      else if (_n.y < 0.62 && V > 12) reason = 'You flew into the terrain.';
      else if (wasAir && V > 14 && (Math.abs(bank) > 0.5 || eul.x < -0.4))
        reason = 'Touched down at a bad attitude.';
      if (reason) {
        this.crashed = reason;
        this.vel.set(0, 0, 0);
        return;
      }
      this.onGround = true;
      this.pos.y = this.surfaceY + wh;
      const vdn = this.vel.x * _n.x + this.vel.y * _n.y + this.vel.z * _n.z;
      if (vdn < 0) this.vel.addScaledVector(_tmp.set(_n.x, _n.y, _n.z), -vdn);

      // ground handling
      _fwd.set(0, 0, -1).applyQuaternion(this.quat);
      _fwd.y = 0;
      if (_fwd.lengthSq() < 1e-6) _fwd.set(0, 0, -1);
      _fwd.normalize();
      _right.set(-_fwd.z, 0, _fwd.x); // fwd x up
      let gs = this.vel.dot(_fwd);
      let lat = this.vel.dot(_right);
      const pave = onPavement(this.pos.x, this.pos.z);
      const decel = (pave ? 0.025 : 0.2) * G + (c.brake ? sp.brakeDecel * G : 0);
      const dec = decel * dt;
      gs = Math.abs(gs) <= dec ? 0 : gs - Math.sign(gs) * dec;
      lat *= Math.exp(-dt * 8);
      const vy = Math.max(0, this.vel.y);
      this.vel.set(0, 0, 0).addScaledVector(_fwd, gs).addScaledVector(_right, lat);
      this.vel.y = vy;

      let yaw = eul.y;
      let pitch = eul.x;
      yaw += -yIn * 0.55 * clamp(0.35 + Math.abs(gs) / 10, 0.35, 1) * dt;
      const target = gs > sp.vRotate * 0.9 ? Math.max(0, pIn) * 0.22 : 0;
      pitch += (target - pitch) * (1 - Math.exp(-dt * 2.5));
      this.quat.setFromEuler(_e.set(pitch, yaw, 0, 'YXZ'));
      this.rateP = this.rateR = this.rateY = 0;
      this.alpha = pitch;
    } else {
      this.onGround = false;
    }
  }
}
